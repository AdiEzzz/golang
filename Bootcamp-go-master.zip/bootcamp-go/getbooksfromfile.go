package bootcamp

import (
	"bufio"
	"os"
)

type Book struct {
	Name   string
	Author string
	Year   int
}

func GetBooksFromCsv(path string) []*Book {
	file, _ := os.Open(path)

	defer file.Close()

	scanner := bufio.NewScanner(file)
	var lines [][]string

	for scanner.Scan() {
		line := scanner.Text() // Считываем строку
		var record []string    // Создаем слайс для хранения полей строки
		field := ""

		for _, char := range line {
			if char == ',' {
				record = append(record, field)
				field = ""
			} else {
				field += string(char)
			}
		}
		record = append(record, field) // Добавляем последнее поле
		lines = append(lines, record)  // Добавляем строку в общий список строк
	}

	// Проверяем, что файл содержит хотя бы две строки (заголовок и данные)
	if len(lines) < 2 {
		return nil
	}

	// Читаем заголовок и определяем индексы столбцов
	header := lines[0]
	var nameIndex, authorIndex, yearIndex int
	for i, h := range header {
		if h == "Name" {
			nameIndex = i
		} else if h == "Author" {
			authorIndex = i
		} else if h == "Year" {
			yearIndex = i
		}
	}

	var books []*Book

	// Читаем данные строк и создаем структуры Book
	for _, record := range lines[1:] {
		if len(record) != len(header) {
			continue // Пропускаем некорректные записи
		}

		// Преобразуем год из строки в целое число
		year := 0
		for _, char := range record[yearIndex] {
			year = year*10 + int(char-'0')
		}

		// Создаем новую структуру Book
		book := &Book{
			Name:   record[nameIndex],
			Author: record[authorIndex],
			Year:   year,
		}
		books = append(books, book) // Добавляем книгу в список
	}

	return books
}

// func main() {
// 	books := GetBooksFromCsv("books.csv")
// 	for _, b := range books {
// 		fmt.Println(b.Name, b.Author, b.Year)
// 	}

// 	books2 := GetBooksFromCsv("books2.csv")
// 	for _, b := range books2 {
// 		fmt.Println(b.Name, b.Author, b.Year)
// 	}
// }
