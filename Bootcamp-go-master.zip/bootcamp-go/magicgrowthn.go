package bootcamp

// import "fmt"

// func MagicGrowthN(n int) []string {
// 	if n < 1 || n > 10{
// 		return []string
// 	}
// }

func MagicGrowthN(n int) []string {
	if n < 1 || n > 10 {
		return []string{}
	}
	return generateCombinations("", "0123456789", n)
}

func generateCombinations(prefix, digits string, n int) []string {
	if n == 0 {
		return []string{prefix}
	}
	var combinations []string
	for i := 0; i < len(digits); i++ {
		combinations = append(combinations, generateCombinations(prefix+string(digits[i]), digits[i+1:], n-1)...)
	}
	return combinations
}

// func main() {
// 	fmt.Println(MagicGrowthN(1))  // ["1", "2", "3", "4", "5", "6", "7", "8", "9"]
// 	fmt.Println(MagicGrowthN(2))  // ["01", "02", ... "08", "09", "12", "13" ... "78", "79", "89"]
// 	fmt.Println(MagicGrowthN(3))  // ["012", "013", ... "089", "123", "123" ... "678", "679", "789"]
// 	fmt.Println(MagicGrowthN(9))  // ["012345678", "123456789"]
// 	fmt.Println(MagicGrowthN(10)) // ["0123456789"]
// }
