package bootcamp

// import "fmt"

func RunesLen(arr [20]rune) int {
	count := 0
	for _, v := range arr {
		if v == 0 {
			return count
		}
		count++
	}
	return count
}

// func main() {
//     arr := [20]rune{'a', 'b', 'c', , 'e'}
//     length := RunesLen(arr)
//     // 3
// }
