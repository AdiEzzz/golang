package bootcamp

// import "fmt"

func Brackets(s string) bool {
	if len(s) <= 1 {
		return false
	}

	var stack []string
	var tmp string

	for _, v := range s {
		if v == '(' || v == '[' || v == '{' {
			stack = append(stack, string(v))
		}
		if v == ')' || v == ']' || v == '}' {
			if len(stack) == 0 {
				return false
			}
			tmp = string(stack[len(stack)-1])

			if tmp == "(" && string(v) == ")" || tmp == "[" && string(v) == "]" || tmp == "{" && string(v) == "}" {
				stack = stack[:len(stack)-1]
			} else {
				return false
			}

		}

	}
	if len(stack) == 0 {
		return true
	}
	return false
}

// func main() {
// 	fmt.Println(Brackets("salem (student) {test} [example]")) // true
// 	fmt.Println(Brackets("test (salem [student)"))            // false
// 	fmt.Println(Brackets("?.fas<. {[...]} (())"))             // true
// 	fmt.Println(Brackets("({[)}]"))                           // false
// }
