package bootcamp

import (
	"bootcamp/btree"
)

func IsBalancedBtree(b *btree.BTree) bool {
	if b.Root == nil {
		return true
	}

	return isBalance(b.Root)
}

func isBalance(b *btree.BTreeNode) bool {
	lHeight := b.Left.BHeight()
	rHeigth := b.Right.BHeight()
	if lHeight-rHeigth < -1 || lHeight-rHeigth > 1 {
		return false
	}
	return true
}
