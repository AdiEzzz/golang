package bootcamp

// import "fmt"

func MergeSort(arr []int) {
	if len(arr) <= 1 {
		return
	}
	MergeSort(arr[:len(arr)/2])
	MergeSort(arr[len(arr)/2:])

	var res []int
	p1, p2 := 0, len(arr)/2
	for i := 0; i < len(arr); i++ {
		if p1 == len(arr)/2 {
			res = append(res, arr[p2:]...)
			break
		} else if p2 == len(arr) {
			res = append(res, arr[p1:len(arr)/2]...)
			break
		}

		if arr[p1] > arr[p2] {
			res = append(res, arr[p2])
			p2++
		} else {
			res = append(res, arr[p1])
			p1++
		}
	}
	copy(arr, res)
}

// func main() {
// 	arr := []int{38, 27, 43}
// 	MergeSort(arr)
// 	fmt.Println(arr)
// 	// Output: [3 9 10 27 38 43 82]
// }
