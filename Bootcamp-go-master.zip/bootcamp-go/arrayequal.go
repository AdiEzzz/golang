package bootcamp
// import "fmt"


func ArrayEqual(arr1, arr2 *[20]int) bool {
	if len(arr1) != len(arr2){
		return false
	}
	for i, v := range arr1 {
		if arr2[i] != v{
			return false
		}	
	}
	return true
}

// func main() {
//     arr1 := [20]int{}
//     arr2 := [20]int{77, 69, 76, 65}
//     fmt.Println(ArrayEqual(&arr1, &arr2)) // true
//     fmt.Println(ArrayEqual(&arr1, &[20]int{77, 78})) // false
// }