package bootcamp

func EightQueens() [][]int {
	var solutions [][]int
	board := make([]int, 8)
	var backtrack func(row int)
	backtrack = func(row int) {
		if row == 8 {
			solution := make([]int, 8)
			for i, v := range board {
				solution[i] = v + 1
			}
			solutions = append(solutions, solution)
			return
		}

		for col := 0; col < 8; col++ {
			if isSafe(board, row, col) {
				board[row] = col
				backtrack(row + 1)
			}
		}
	}

	backtrack(0)
	return solutions
}

func isSafe(board []int, row, col int) bool {
	for prevRow := 0; prevRow < row; prevRow++ {
		if board[prevRow] == col ||
			board[prevRow]-prevRow == col-row ||
			board[prevRow]+prevRow == col+row {
			return false
		}
	}
	return true
}
