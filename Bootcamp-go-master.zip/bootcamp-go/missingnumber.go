package bootcamp

func MissingNumber(arr []int) int {
	filtered := make([]int, 0)
	for _, num := range arr {
		if num > 0 {
			filtered = append(filtered, num)
		}
	}

	n := len(filtered)
	present := make([]bool, n+1)

	for _, num := range filtered {
		if num <= n {
			present[num-1] = true
		}
	}

	for i := 0; i <= n; i++ {
		if !present[i] {
			return i + 1
		}
	}

	return n + 1
}
