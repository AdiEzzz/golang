package bootcamp

// import "fmt"

func RotN(s string, n int) string {
	var res string
	for _, char := range s {
		if char >= 'A' && char <= 'Z' {
			res += string((char-'A'+rune(n))%26 + 'A')
		} else if char >= 'a' && char <= 'z' {
			res += string((char-'a'+rune(n))%26 + 'a')
		} else {
			res += string(char)
		}
	}
	return res
}

// func main() {
// 	fmt.Println(RotN("salem", -1))
// 	fmt.Println(RotN("abc", 13))
// }
