package main

import "github.com/alem-platform/ap"

func main() {
	for _, v := range "0123456789" {
		ap.PutRune(v)
	}
	ap.PutRune('\n')
}
