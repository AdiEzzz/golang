package bootcamp

// import "fmt"

func Trim(s string) string {
	var idx1, idx2 int = 0, 0
	for _, v := range s {
		if v == ' ' {
			idx1++
		} else {
			break
		}
	}

	for i := len(s) - 1; i >= 0; i-- {
		if s[i] == ' ' {
			idx2++
		} else {
			break
		}
	}

	return s[idx1 : len(s)-idx2]
}

// func main() {
// 	fmt.Println(Trim("   Salem student!   "))
// 	fmt.Println(Trim("   Trim spaces   "))
// 	fmt.Println(Trim("1"))
// }
