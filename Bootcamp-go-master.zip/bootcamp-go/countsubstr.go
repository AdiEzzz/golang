package bootcamp

// import "fmt"

func CountSubstr(s string, substr string) int {
	var count int = 0

	for i := 0; i < len(s); i++ {
		if i+len(substr) <= len(s) && s[i:i+len(substr)] == substr {
			count++
		}
	}
	return count
}

// func main() {
// 	fmt.Println(CountSubstr("qwe", ""))
// }
