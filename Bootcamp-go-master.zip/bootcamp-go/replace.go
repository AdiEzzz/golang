package bootcamp

// import "fmt"

func Replace(s string, old string, new string) string {
	var res string
	// var start int = 0

	for i := 0; i < len(s); i++ {
		if i+len(old) <= len(s) && s[i:i+len(old)] == old {
			res += new
			i += len(old)
			// res = append(res, append(new, s[start+len(new):]))
		}
		if i < len(s) {
			res += string(s[i])
		}

	}
	// res += s[start:]
	return res
}

// func main() {
// 	fmt.Println(Replace("Hello student!", "Hello", "Salem"))
// 	fmt.Println(Replace("banana", "a", "o"))
// 	fmt.Println(Replace("banana", "a", ""))
// }
