package main

import (
	"os"

	"github.com/alem-platform/ap"
)

func main() {
	filename := os.Args[0]
	PrintString(filename[2:])
	ap.PutRune('\n')
}

func PrintString(s string) {
	str := []rune(s)
	for i := 0; i < len(str); i++ {
		ap.PutRune(str[i])
	}
}
