package bootcamp

// import "fmt"

func MapValues(m map[string]int) []int {
	var res []int
	for _, v := range m {
		res = append(res, v)
	}
	return res
}

// func main() {
// 	m := map[string]int{"one": 1, "two": 2, "three": 3}
// 	values := MapValues(m)
// 	fmt.Println(values) // [1 2 3]
// }
