package bootcamp

func ValidSudoku(board [9][9]int) bool {
	// Check each row
	for row := 0; row < 9; row++ {
		if !isValidUnit(board[row][:]) {
			return false
		}
	}

	// Check each column
	for col := 0; col < 9; col++ {
		column := make([]int, 9)
		for row := 0; row < 9; row++ {
			column[row] = board[row][col]
		}
		if !isValidUnit(column) {
			return false
		}
	}

	// Check each 3x3 subgrid
	for blockRow := 0; blockRow < 3; blockRow++ {
		for blockCol := 0; blockCol < 3; blockCol++ {
			block := make([]int, 0, 9)
			for row := blockRow * 3; row < blockRow*3+3; row++ {
				for col := blockCol * 3; col < blockCol*3+3; col++ {
					block = append(block, board[row][col])
				}
			}
			if !isValidUnit(block) {
				return false
			}
		}
	}

	return true
}

// Function to check if a unit (row, column, or subgrid) is valid
func isValidUnit(unit []int) bool {
	seen := make(map[int]bool)
	for _, num := range unit {
		if num != 0 { // 0 represents empty cells, which are always valid
			if seen[num] {
				return false
			}
			seen[num] = true
		}
	}
	return true
}

/*
func main() {
	validSudoku := [9][9]int{
		{5, 3, 4, 6, 7, 8, 9, 1, 2},
		{6, 7, 2, 1, 9, 5, 3, 4, 8},
		{1, 9, 8, 3, 4, 2, 5, 6, 7},
		{8, 5, 9, 7, 6, 1, 4, 2, 3},
		{4, 2, 6, 8, 5, 3, 7, 9, 1},
		{7, 1, 3, 9, 2, 4, 8, 5, 6},
		{9, 6, 1, 5, 3, 7, 2, 8, 4},
		{2, 8, 7, 4, 1, 9, 6, 3, 5},
		{3, 4, 5, 2, 8, 6, 1, 7, 9},
	}

	invalidSudoku := [9][9]int{
		{5, 3, 4, 6, 7, 8, 9, 1, 2},
		{6, 7, 2, 1, 9, 5, 3, 4, 8},
		{1, 9, 8, 3, 4, 2, 5, 6, 7},
		{8, 5, 9, 7, 6, 1, 4, 2, 3},
		{4, 2, 6, 8, 5, 3, 7, 9, 1},
		{7, 1, 3, 9, 2, 4, 8, 5, 6},
		{9, 6, 1, 5, 3, 7, 2, 8, 4},
		{2, 8, 7, 4, 1, 9, 6, 3, 5},
		{3, 4, 5, 2, 8, 6, 1, 7, 8}, // invalid row
	}

	fmt.Println("Valid Sudoku:", ValidSudoku(validSudoku))     // true
	fmt.Println("Invalid Sudoku:", ValidSudoku(invalidSudoku)) // false
}
*/
