#!/bin/bash

if [ ! -f "access.log" ]; then
	echo "Error:access.log file not found."
	exit 1
fi
head access.log
