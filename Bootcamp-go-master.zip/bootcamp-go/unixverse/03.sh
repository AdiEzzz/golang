tail -1 movies.csv | cut -d',' -f 5
