cat movies.csv | cut -d ',' -f 2 | tr '[:lower:]' '[:upper:]'
