package bootcamp

import "github.com/alem-platform/ap"

func PutDigit(n int) {
	if n >= 0 && n <= 9 {
		ap.PutRune(rune(n + '0'))
	}
}

// func main() {
// 	PutDigit(8)
// 	// Output:
// 	// 3
// }
