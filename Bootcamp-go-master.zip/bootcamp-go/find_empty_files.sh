#!/bin/bash                                                                                                                                                     

script_name=$(basename "$0")
                                                                                                                    
if [ "$#" -eq 0 ]; then
  echo "usage: $script_name dir_path"
  exit 0
fi

                                                                                                              
dir_path="$1"

                                                                                                           
if [ ! -d "$dir_path" ]; then
  if [ -e "$dir_path" ]; then
    echo "error: $dir_path is not a directory"
  else
    echo "error: directory $dir_path not found"
  fi
  exit 0
fi
                                                                                                  
find "$dir_path" -type f | while IFS= read -r file; do
  if [ ! -s "$file" ] || [ -z "$(grep -v '^\s*$' "$file")" ]; then
    echo "$file"
  fi
done


