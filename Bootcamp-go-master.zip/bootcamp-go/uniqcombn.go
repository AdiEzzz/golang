package bootcamp

// import "fmt"

func UniqCombN(characters string, n int) []string {
	if len(characters) < n || len(characters) == 0 || n == 0 {
		return []string{}
	}
	// check if every char characters is unique
	for i, v := range characters {
		for _, c := range characters[i+1:] {
			if v == c {
				return []string{}
			}
		}
	}

	var res []string
	permute(characters, "", n, &res)
	return res
}

func permute(s, curr string, n int, res *[]string) {
	if len(curr) == n {
		*res = append(*res, curr)
		return
	}

	for i := 0; i < len(s); i++ {
		permute(s[:i]+s[i+1:], curr+string(s[i]), n, res)
	}
}

// func main() {
// 	fmt.Println(UniqCombN("abc", 1)) // ["a", "b", "c"]
// 	fmt.Println(UniqCombN("abc", 2)) // ["ab", "ac", "ba", "bc", "ca", "cb"]
// 	fmt.Println(UniqCombN("ab", 2))  // ["ab", "ba"]
// 	fmt.Println(UniqCombN("a", 1))   // ["a"]
// 	fmt.Println(UniqCombN("ab", 3))  // []
// 	fmt.Println(UniqCombN("aa", 1))  // []
// }
