package bootcamp
// import "fmt"


func SliceAppendN(n int) []int {
	var res []int
	if n <= 0{
		return res
	}
	for i := 0; i < n; i++ {
		res = append(res, i)
	}
	return res
}

// func main(){
// 	fmt.Println(SliceMakeN(10000))  // [0, 1, 2, 3, 4]
//     fmt.Println(SliceMakeN(10)) // [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
// }