package bootcamp

// import "fmt"

func UniqComb2(characters string) []string {
	if len(characters) < 2 {
		return []string{}
	}
	// check if every char characters is unique
	for i, v := range characters {
		for _, c := range characters[i+1:] {
			if v == c {
				return []string{}
			}
		}
	}

	var result []string

	for i := 0; i < len(characters); i++ {
		for j := 0; j < len(characters); j++ {
			if i != j {
				result = append(result, string(characters[i])+string(characters[j]))
			}
		}
	}
	return result
}

// func main() {
// 	fmt.Println(UniqComb2("abc")) // ["ab", "ac", "ba", "bc", "ca", "cb"]
// 	fmt.Println(UniqComb2("ab"))  // ["ab", "ba"]
// 	fmt.Println(UniqComb2("a"))   // []
// 	fmt.Println(UniqComb2("aba")) // []
// 	fmt.Println(UniqComb2("abc")) // []
// }
