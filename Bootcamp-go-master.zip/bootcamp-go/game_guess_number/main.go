package main

import (
	"fmt"
	"math/rand"

	"github.com/alem-platform/ap"
)

func main() {
	guessed_num := rand.Int() % 100
	user_guess := 0
	isWin := false
	for !isWin {
		prints("Guess number: ")
		fmt.Scanf("%d", &user_guess)
		if user_guess == guessed_num {
			isWin = true
			prints("Match, you win!\n")
			break
		}
		if user_guess > guessed_num {
			prints("Lower\n")
		} else {
			prints("Higher\n")
		}
	}
}

func prints(s string) {
	str := []rune(s)
	for i := 0; i < len(str); i++ {
		ap.PutRune(str[i])
	}
}
