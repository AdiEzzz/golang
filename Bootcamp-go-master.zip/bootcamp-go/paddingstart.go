package bootcamp

func PaddingStart(s string, totalLength int) string {
	res := ""
	for i := 0; i < totalLength-runesCount(s); i++ {
		res += " "
	}
	res += s
	return res
}

func runesCount(s string) int {
	count := 0
	for _, v := range s {
		if v != -1 {
			count++
		}
	}
	return count
}

// func main() {
// 	fmt.Printf("%q\n", PaddingStart("salem", 10))
// 	fmt.Printf("%q\n", PaddingStart("salem😃", 10))
// 	fmt.Printf("%q\n", PaddingStart("salem", 4))
// }
