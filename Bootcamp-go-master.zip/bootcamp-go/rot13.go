package bootcamp

// import "fmt"

func Rot13(s string) string {
	var res string
	for _, char := range s {
		if char >= 'A' && char <= 'Z' {
			res += string((char-'A'+rune(13))%26 + 'A')
		} else if char >= 'a' && char <= 'z' {
			res += string((char-'a'+rune(13))%26 + 'a')
		} else {
			res += string(char)
		}
	}
	return res
}

// func main() {
// 	fmt.Println(Rot13("salem"))
// 	fmt.Println(Rot13("fnyrz"))
// }
