package bootcamp

// import "fmt"

func IsNumeric(s string) bool {
	if s[0] != '+' && s[0] != '-' && (s[0] < '0' || s[0] > '9') || len(s) == 1 && (s[0] < '0' || s[0] > '9') {
		return false
	}
	for _, v := range s[1:] {
		if v < '0' || v > '9' {
			return false
		}
	}
	return true
}

// func main() {
// 	fmt.Println(IsNumericSimple("123"))     // true
// 	fmt.Println(IsNumericSimple("-123"))    // true
// 	fmt.Println(IsNumericSimple("+123"))    // true
// 	fmt.Println(IsNumericSimple("+-123"))   // false
// 	fmt.Println(IsNumericSimple(" 123"))    // false
// 	fmt.Println(IsNumericSimple("123 abc")) // false
// 	fmt.Println(IsNumericSimple("123abc"))  // false
// 	fmt.Println(IsNumericSimple("ab"))      // false
// }
