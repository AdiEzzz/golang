package bootcamp

// import "fmt"

func SliceSort(arr []int) {
	var tmp int
	for i := 0; i < len(arr); i++ {
		for j := 0; j < len(arr); j++ {
			if i == j {
				continue
			}
			if arr[j] > arr[i] {
				tmp = arr[i]
				arr[i] = arr[j]
				arr[j] = tmp
			}
		}
	}
}

// func main() {
// 	arr := []int{10, 90, 20, 5, 12, 3, 0}
// 	SliceSort(arr)
// 	fmt.Println(arr) // [0, 3, 5, 10, 12, 20, 90]
// }
