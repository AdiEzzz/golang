package bootcamp

// import (
// 	"github.com/alem-platform/ap"
// )

func SliceMatrixRotateN(matrix [][]rune, turns int) {
	if len(matrix) <= 0 {
		return
	}
	if len(matrix) != len(matrix[0]) || turns == 0 {
		return
	}
	turns = turns % 4
	if turns < 0 {
		turns += 4
	}

	for i := 0; i < turns; i++ {
		for i, j := 0, len(matrix)-1; i < j; i, j = i+1, j-1 {
			matrix[i], matrix[j] = matrix[j], matrix[i]
		}

		for i := 0; i < len(matrix); i++ {
			for j := 0; j < i; j++ {
				matrix[i][j], matrix[j][i] = matrix[j][i], matrix[i][j]
			}
		}
	}
}

// func main() {
// 	matrix := [][]rune{
// 		{'a', 'b', 'c'},
// 		{'d', 'e', 'f'},
// 		{'g', 'h', 'i'},
// 	}

// 	SliceMatrixPrint(matrix)
// 	// Output:
// 	// a b c
// 	// d e f
// 	// g h i
// 	ap.PutRune('\n')
// 	ap.PutRune('\n')
// 	SliceMatrixRotateN(matrix, 1)

// 	SliceMatrixPrint(matrix)
// 	// Output:
// 	// g d a
// 	// h e b
// 	// i f c

// 	SliceMatrixRotateN(matrix, -2)
// 	ap.PutRune('\n')
// 	ap.PutRune('\n')
// 	SliceMatrixPrint(matrix)
// 	// Output:
// 	// c f i
// 	// b e h
// 	// a d g
// 	SliceMatrixRotateN([][]rune{}, -2)
// }

// func SliceMatrixPrint(matrix [][]rune) {
// 	for w, i := range matrix {
// 		for n, v := range i {
// 			ap.PutRune(v)
// 			if n < len(matrix[0])-1 {
// 				ap.PutRune(' ')
// 			}
// 		}
// 		if w < len(matrix)-1 {
// 			ap.PutRune('\n')
// 		}
// 	}
// }
