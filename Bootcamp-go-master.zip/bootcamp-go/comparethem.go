package bootcamp

// import "fmt"

func CompareThem(a, b *int) bool {
	if a == nil && b != nil || a != nil && b == nil {
		return false
	} else if a == b || *a == *b {
		return true
	} else {
		return false
	}
}

// func main() {
// 	// var first int = 10
// 	// var second int = 11
// 	var third int = 10

// 	fmt.Println(CompareThem(nil, nil))    // false
// 	fmt.Println(CompareThem(nil, &third)) // true
// }
