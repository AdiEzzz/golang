package bootcamp

import "github.com/alem-platform/ap"

func PutNumber(n int) {
	if n < 0 {
		ap.PutRune('-')
		n = n - 2*n
	}
	if n == 0 {
		return
	}
	tmp := n % 10
	PutNumber(n / 10)
	ap.PutRune(rune(tmp + '0'))
}

// func main() {
// 	PutNumber(-9876453686)
// 	// Output:
// 	// 2024
// }
