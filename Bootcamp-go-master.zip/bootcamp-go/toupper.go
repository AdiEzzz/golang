package bootcamp

// import "fmt"

func ToUpper(s string) string {
	var res string
	for _, v := range s {
		if v >= 'a' && v <= 'z' {
			res += string(rune(v - 32))
		} else {
			res += string(v)
		}
	}
	return res
}

// func main() {
// 	fmt.Println(ToUpper("salem "))        // "SALEM "
// 	fmt.Println(ToUpper("Salem Student")) // "SALEM STUDENT"
// 	fmt.Println(ToUpper("S46+5m"))        // "S4LEM"
// }
