package bootcamp

// import "fmt"

func SliceBatch(slice []int, size int) [][]int {
	var res [][]int
	if size <= 0 {
		return res
	}
	for i := 0; i < len(slice); {
		end := size
		if l := len(slice[i:]); l < size {
			end = l
		}

		res = append(res, slice[i:i+end:i+end])
		i += end
	}

	return res
}

// func main() {
// 	arr := []int{1, 2, 3, 4, 5, 6, 7}
// 	batch := SliceBatch(arr, 0)
// 	for _, v := range batch {
// 		fmt.Println(v)
// 	}
// 	// Output:
// 	// [1, 2]
// 	// [3, 4]
// 	// [5, 6]
// 	// [7]
// }
