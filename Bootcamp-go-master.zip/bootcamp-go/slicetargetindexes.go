package bootcamp

// import "fmt"


func SliceTargetIndexes(arr []int, target int) []int {
	var res []int
	for i, v := range arr {
		if v == target{
			res = append(res, i)
		}
	}
	return res
}

// func main() {
//     var arr = []int{}
//     fmt.Println(SliceTargetIndexes(arr, 2)) // [0, 2, 7]
//     fmt.Println(SliceTargetIndexes(arr, 1)) // []
// }