#!/bin/bash
ls total/ -l | wc -l
