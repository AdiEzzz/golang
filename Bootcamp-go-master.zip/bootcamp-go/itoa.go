package bootcamp

// import "fmt"

func Itoa(n int) string {
	if n == 0 {
		return "0"
	}
	var res string
	isMinus := n < 0
	if isMinus {
		n = -n
	}

	for n > 0 {
		tmp := n % 10
		res = string('0'+tmp) + res
		n /= 10
	}

	if isMinus {
		res = "-" + res
	}
	return res
}

// func main() {
// 	fmt.Println(Itoa(123))
// 	fmt.Println(Itoa(-456))
// 	fmt.Println(Itoa(0))
// }
