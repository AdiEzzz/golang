package main

import (
	"os"

	"github.com/alem-platform/ap"
)

func main() {
	args := os.Args[1:]
	for _, v := range args {
		printString(v)
		ap.PutRune('\n')
	}
}

func printString(s string) {
	str := []rune(s)
	for i := 0; i < len(str); i++ {
		ap.PutRune(str[i])
	}
}
