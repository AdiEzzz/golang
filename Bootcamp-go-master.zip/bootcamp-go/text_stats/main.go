package main

import (
	"bufio"
	"fmt"
	"os"
)

// Hello world. How are you today? I hope fine!159
func main() {
	scanner := bufio.NewScanner(os.Stdin)
	fmt.Print("Enter text: ")
	sentences, words, letters, vowels, consonants, digits, spaces, spec_chars := 0, 0, 0, 0, 0, 0, 0, 0

	onWord := false

	if scanner.Scan() {
		text := scanner.Text()
		n := len(text)
		fmt.Println("Characters:", n)
		for i := 0; i < n; i++ {
			if (text[i] == '?' || text[i] == '!' || text[i] == '.') && text[i-1] != '?' && text[i-1] != '!' && text[i-1] != '.' && i != 0 {
				sentences++
			}

			if text[i] >= 'a' && text[i] <= 'z' || text[i] >= 'A' && text[i] <= 'Z' {
				letters++
				if text[i] == 'a' || text[i] == 'e' || text[i] == 'i' || text[i] == 'o' || text[i] == 'u' || text[i] == 'A' || text[i] == 'E' || text[i] == 'I' || text[i] == 'O' || text[i] == 'U' {
					vowels++
				} else {
					consonants++
				}
			}

			// Word count
			if text[i] >= 'a' && text[i] <= 'z' || text[i] >= 'A' && text[i] <= 'Z' || onWord && text[i] >= '0' && text[i] <= '9' {
				onWord = true
			} else {
				if onWord {
					onWord = false
					words++
				}
			}

			if text[i] >= '0' && text[i] <= '9' {
				digits++
			}
			if text[i] == ' ' {
				spaces++
			}
		}

		if onWord {
			words++
		}

		if text[n-1] != '?' && text[n-1] != '!' && text[n-1] != '.' {
			sentences++
		}

		spec_chars = n - letters - spaces - digits
		fmt.Println("Sentences:", sentences)
		fmt.Println("Words:", words)
		fmt.Println("Letters:", letters)
		fmt.Println("Vowels:", vowels)
		fmt.Println("Consonants:", consonants)
		fmt.Println("Digits:", digits)
		fmt.Println("Spaces:", spaces)
		fmt.Println("Special Characters:", spec_chars)
		// Code
	} else {
		fmt.Println("Error reading input:", scanner.Err())
	}
}
