package bootcamp

import "bootcamp/btree"

func LevelsBtree(b *btree.BTree) int {
	return b.Root.BHeight()
}
