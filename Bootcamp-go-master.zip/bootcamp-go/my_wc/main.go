package main

import (
	"os"

	"github.com/alem-platform/ap"
)

func main() {
	args := os.Args[1:]
	var command, filename string

	if len(args) == 0 {
		printString("usage: my_wc [-lwc] file\n")
		return
	}

	if len(args) == 2 {
		command = args[0]
		filename = args[1]
	} else {
		filename = args[0]
	}
	content, err := os.ReadFile(filename)
	if err != nil {
		printString("my_wc: ")
		printString(filename + ":")
		printString(" No such file or directory\n")
		return
	}

	onWord := false
	lines, words, bytes := 0, 0, len(content)
	var last rune
	for _, v := range content {
		if v < 'A' || v > 'Z' && v < 'a' || v > 'z' {
			if onWord {
				words++
				onWord = false
			}
		} else {
			onWord = true
		}
		if v == '\n' {
			lines++
		}
		last = rune(v)
	}
	if last != '\n' {
		lines++
	}
	switch command {
	case "-l":
		number(lines)
		printString(" " + filename)
	case "-w":
		number(words)
		printString(" " + filename)
	case "-c":
		number(bytes)
		printString(" " + filename)
	default:
		number(lines)
		ap.PutRune(' ')
		number(words)
		ap.PutRune(' ')
		number(bytes)
		printString(" " + filename)
	}
	ap.PutRune('\n')
}

func printString(s string) {
	str := []rune(s)
	for i := 0; i < len(str); i++ {
		ap.PutRune(str[i])
	}
}

func number(n int) {
	if n == 0 {
		return
	}
	tmp := n % 10
	number(n / 10)
	ap.PutRune(rune(tmp + '0'))
}
