#!/bin/bash
find $(find ~ -type d -name "*lost+found*") -type f -name "*force*"
