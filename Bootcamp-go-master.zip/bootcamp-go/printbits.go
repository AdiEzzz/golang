package bootcamp

import "github.com/alem-platform/ap"

// PrintBits prints the binary representation of a byte

func PrintBits(n byte) {
	for i := 7; i >= 0; i-- {
		bit := (n >> i) & 1
		ap.PutRune(rune(bit) + '0')
	}
	ap.PutRune('\n')
}

// func main() {
// 	PrintBits(5)   // Output: 00000101
// 	PrintBits(255) // Output: 11111111
// 	PrintBits(0)   // Output: 00000000
// }
