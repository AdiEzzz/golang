package bootcamp

// import "fmt"

func FibonacciIterative(n int) int {
	if n < 0 {
		return -1
	}
	if n == 0 {
		return 0
	}

	res := 1
	x1, x2 := 1, 1
	for i := 0; i < n-2; i++ {
		res = x1 + x2
		x1 = x2
		x2 = res
	}
	return res
}

// func main() {
// 	fmt.Println(FibonacciIterative(-1)) // -1
// 	fmt.Println(FibonacciIterative(0))  // 0
// 	fmt.Println(FibonacciIterative(1))  // 1
// 	fmt.Println(FibonacciIterative(2))  // 1
// 	fmt.Println(FibonacciIterative(3))  // 2
// 	fmt.Println(FibonacciIterative(4))  // 3
// 	fmt.Println(FibonacciIterative(5))  // 5
// 	fmt.Println(FibonacciIterative(15)) // 8
// }
