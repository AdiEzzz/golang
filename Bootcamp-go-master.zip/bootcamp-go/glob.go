package bootcamp

func Glob(s string, pattern string) bool {
	sIdx, patternIdx := 0, 0
	sLen, pLen := len(s), len(pattern)
	sStar, pStar := -1, -1

	for sIdx < sLen {
		if patternIdx < pLen && pattern[patternIdx] == '?' {
			sIdx++
			patternIdx++
		} else if patternIdx < pLen && pattern[patternIdx] == '*' {
			pStar = patternIdx
			sStar = sIdx
			patternIdx++
		} else if patternIdx < pLen && pattern[patternIdx] == '[' {
			patternIdx++
			negate := false
			if patternIdx < pLen && (pattern[patternIdx] == '!' || pattern[patternIdx] == '^') {
				negate = true
				patternIdx++
			}
			match := false
			for patternIdx < pLen && pattern[patternIdx] != ']' {
				if patternIdx+1 < pLen && pattern[patternIdx+1] == '-' {
					start := pattern[patternIdx]
					end := pattern[patternIdx+2]
					if (s[sIdx] >= start && s[sIdx] <= end) || (s[sIdx] >= end && s[sIdx] <= start) {
						match = true
					}
					patternIdx += 3
				} else {
					if s[sIdx] == pattern[patternIdx] {
						match = true
					}
					patternIdx++
				}
			}
			if (match && !negate) || (!match && negate) {
				sIdx++
				patternIdx++
			} else {
				return false
			}
		} else if patternIdx < pLen && s[sIdx] == pattern[patternIdx] {
			sIdx++
			patternIdx++
		} else if pStar != -1 {
			patternIdx = pStar + 1
			sStar++
			sIdx = sStar
		} else {
			return false
		}
	}

	for patternIdx < pLen && pattern[patternIdx] == '*' {
		patternIdx++
	}

	return patternIdx == pLen
}
