package bootcamp

// import "fmt"

func IncrementIt(n *int) {
	if n != nil {
		*n++
	}
}

// func main() {
// 	num := 10
// 	IncrementIt(&num)
// 	fmt.Println(num) // 11
// 	IncrementIt(&num)
// 	fmt.Println(num) // 12
// }
