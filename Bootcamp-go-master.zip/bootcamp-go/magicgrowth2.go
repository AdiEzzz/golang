package bootcamp

// import "fmt"

func MagicGrowth2() []string {
	var res []string
	var tmp string

	for i := 0; i < 9; i++ {
		for j := i + 1; j <= 9; j++ {
			tmp += string(rune(i + '0'))
			tmp += string(rune(j + '0'))
			res = append(res, tmp)
			tmp = ""
		}
	}
	return res
}

// func main() {
// 	fmt.Println(MagicGrowth2()) // ["01", "02", ... "08", "09", "12", "13" ... "78", "79", "89"]
// }
