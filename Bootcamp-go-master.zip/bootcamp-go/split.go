package bootcamp

// import (
// 	"fmt"
// )

func Split(s string, sep string) []string {
	var res []string
	var start int = 0
	if len(s) == 0 {
		return []string{""}
	}
	if len(sep) == 0 {
		for _, v := range s {
			res = append(res, string(v))
		}
		return res
	}

	for i := 0; i < len(s); i++ {
		if i+len(sep) <= len(s) && s[i:i+len(sep)] == sep {
			res = append(res, s[start:i])
			start = i + len(sep)
		}
	}

	res = append(res, s[start:])
	return res
}

// func main() {
// 	fmt.Println(Split("N@LV1HwLV1qELV1$SMou", "LV1"))
// 	fmt.Println(Split("Yph)}EX)~DsqWd)}E-", ")}E"))
// 	fmt.Println(Split("", "GTqs"))
// }
