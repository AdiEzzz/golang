package main

import (
	"os"

	"github.com/alem-platform/ap"
)

func executeBrainfuck(code string) {
	memory := make([]byte, 30000)
	ptr := 0
	bracketStack := []int{}
	instructionPtr := 0

	for instructionPtr < len(code) {
		switch code[instructionPtr] {
		case '>':
			ptr++
		case '<':
			ptr--
		case '+':
			memory[ptr]++
		case '-':
			memory[ptr]--
		case '.':
			pri(string(memory[ptr]))
		case ',':
			pri(string(memory[ptr]))
		case '[':
			if memory[ptr] == 0 {
				loopDepth := 1
				for {
					instructionPtr++
					if code[instructionPtr] == '[' {
						loopDepth++
					} else if code[instructionPtr] == ']' {
						loopDepth--
						if loopDepth == 0 {
							break
						}
					}
				}
			} else {
				bracketStack = append(bracketStack, instructionPtr)
			}
		case ']':
			if memory[ptr] != 0 {
				instructionPtr = bracketStack[len(bracketStack)-1]
			} else {
				bracketStack = bracketStack[:len(bracketStack)-1]
			}
		}
		instructionPtr++
	}
}

func main() {
	code := os.Args[1]
	executeBrainfuck(code)
}

func pri(c string) {
	for _, s := range c {
		ap.PutRune(s)
	}
}
