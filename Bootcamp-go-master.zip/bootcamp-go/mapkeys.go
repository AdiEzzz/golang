package bootcamp

// import "fmt"

func MapKeys(m map[string]int) []string {
	var res []string
	for i := range m {
		res = append(res, i)
	}
	return res
}

// func main() {
// 	m := map[string]int{"one": 1, "two": 2, "three": 3}
// 	keys := MapKeys(m)
// 	fmt.Println(keys) // [one two three]
// }
