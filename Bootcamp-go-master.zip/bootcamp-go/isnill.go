package bootcamp

// import "fmt"

func IsNil(a *int) bool {
	if a != nil {
		return false
	} else {
		return true
	}
}

// func main() {
// 	var a int = 10
// 	var b *int
// 	fmt.Println(a, IsNil(&a))    // 10 false
// 	fmt.Println(b, IsNil(b))     // <nil> true
// 	fmt.Println(nil, IsNil(nil)) // <nil> true
// }
