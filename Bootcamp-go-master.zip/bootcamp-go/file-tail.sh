#!/bin/bash

tail -10 $filename
