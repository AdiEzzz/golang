package bootcamp

// import (
// 	"fmt"
// )

func Atoi(s string) int {
	if s == "0" {
		return 0
	}
	var res int

	if string(s[0]) == "-" {
		for _, v := range s[1:] {
			if v < '0' || v > '9' {
				return 0
			}
		}
		res = Atoi(s[1:])
		return res - 2*res
	} else if string(s[0]) == "+" {
		for _, v := range s[1:] {
			if v < '0' || v > '9' {
				return 0
			}
		}
		return Atoi(s[1:])
	}

	isDigitsOnly := true
	for _, v := range s {
		if v < '0' || v > '9' {
			isDigitsOnly = false
		}
	}
	if !isDigitsOnly {
		return 0
	}

	res = 0
	for i := 0; i < len(s); i++ {
		res = res*10 + int(s[i]-'0')
	}

	return res
}

// func main() {
// 	fmt.Println(Atoi("123"))
// 	fmt.Println(Atoi("+123"))
// 	fmt.Println(Atoi("-123"))
// 	fmt.Println(Atoi("-123!"))
// 	fmt.Println(Atoi("abc"))
// }
