package bootcamp

// import "fmt"

// // func Capitalize(s string) string {
// // 	if len(s) == 0 {
// // 		return s
// // 	}

// // 	for i, v := range s {
// // 		if v >= 'A' && v <= 'Z' {
// // 			s[i] = rune(v + 32)
// // 		}
// // 	}
// // 	s[0] = s[0] - 32
// // 	return s
// // }

func isLetter(r byte) bool {
	return (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z')
}

func toUpper(r byte) byte {
	if r >= 'a' && r <= 'z' {
		return r - 'a' + 'A'
	}
	return r
}

func toLower(r byte) byte {
	if r >= 'A' && r <= 'Z' {
		return r - 'A' + 'a'
	}
	return r
}

func Capitalize(s string) string {
	var result []byte
	var capitalizeNext bool = true
	if isLetter(s[0]) == false {
		capitalizeNext = false
	}

	for i := 0; i < len(s); i++ {
		if capitalizeNext && isLetter(s[i]) {
			result = append(result, toUpper(s[i]))
			capitalizeNext = false
		} else {
			result = append(result, toLower(s[i]))
		}

		if s[i] == ' ' {
			capitalizeNext = true
		}
	}

	return string(result)
}

// func main() {
// 	fmt.Println(Capitalize("salem student"))
// 	fmt.Println(Capitalize("SALEM-5TUDENT, Q41aisyn?"))
// }
