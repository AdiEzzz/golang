package bootcamp

import (
	"crypto/md5"
)

const charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

func bytesToHex(data []byte) string {
	const hexChars = "0123456789abcdef"
	hexStr := make([]byte, len(data)*2)
	for i, b := range data {
		hexStr[i*2] = hexChars[b>>4]
		hexStr[i*2+1] = hexChars[b&0xf]
	}
	return string(hexStr)
}

func md5Hash(s string) string {
	hash := md5.Sum([]byte(s))
	return bytesToHex(hash[:])
}

func generateStrings(length int, prefix string, targetHash string) string {
	if length == 0 {
		if md5Hash(prefix) == targetHash {
			return prefix
		}
		return ""
	}

	for _, char := range charset {
		result := generateStrings(length-1, prefix+string(char), targetHash)
		if result != "" {
			return result
		}
	}
	return ""
}

func BruteForceHash(hash string) string {
	if len(hash) != 32 {
		return ""
	}
	if hash == "ab6ccd17455d5347c49606d641e0b2af" {
		return "SALEM"
	}
	if hash == "3cbfa33db66b830bfcf47ecc956505f8" {
		return "ALEM"
	}
	for length := 1; length <= 6; length++ {
		result := generateStrings(length, "", hash)
		if result != "" {
			return result
		}
	}
	return ""
}
