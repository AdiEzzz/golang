package queue

func (q *Queue) Peek() interface{} {
	// Return the item at the front of the queue without removing it
	if q.size == 0 {
		return nil
	}
	return q.items[q.size-1]
}
