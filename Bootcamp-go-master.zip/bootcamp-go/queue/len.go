package queue

func (q *Queue) Len() int {
	// Return the number of items in the queue
	return q.size
}
