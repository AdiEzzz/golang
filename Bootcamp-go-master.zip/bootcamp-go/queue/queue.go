package queue

type Queue struct { // Implement the internal structure as you see fit
	items []interface{}
	size  int
}

func NewQueue() *Queue {
	return &Queue{}
}

func (q *Queue) Push(v interface{}) {
	q.items = append([]interface{}{v}, q.items...)
	q.size++
}

func (q *Queue) Pop() interface{} {
	if q.size == 0 {
		return nil
	}
	pop := q.items[q.size-1]
	q.size--
	return pop
}
