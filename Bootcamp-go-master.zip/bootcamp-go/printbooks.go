package bootcamp

import "github.com/alem-platform/ap"

func PrintBooks(books []*Book) {
	mxName, mxAuthor := 0, 0

	for i := 0; i < len(books); i++ {
		if len(books[i].Name) > mxName {
			mxName = len(books[i].Name)
		}

		if len(books[i].Author) > mxAuthor {
			mxAuthor = len(books[i].Author)
		}
	}
	printtt("Name")
	printSpaces(mxName - 4)
	ap.PutRune(' ')
	printtt("Author")
	printSpaces(mxAuthor - 6)
	ap.PutRune(' ')
	printtt("Year")
	ap.PutRune('\n')
	for _, v := range books {
		printtt(v.Name)
		printSpaces(mxName - len(v.Name))
		ap.PutRune(' ')
		printtt(v.Author)
		printSpaces(mxAuthor - len(v.Author))
		ap.PutRune(' ')
		printNumber(v.Year)
		ap.PutRune('\n')
	}
}

func printNumber(n int) {
	if n < 0 {
		ap.PutRune('-')
		n = n - 2*n
	}
	if n == 0 {
		return
	}
	tmp := n % 10
	printNumber(n / 10)
	ap.PutRune(rune(tmp + '0'))
}

func printSpaces(n int) {
	for i := 0; i < n; i++ {
		ap.PutRune(' ')
	}
}

func printtt(s string) {
	for _, v := range s {
		ap.PutRune(v)
	}
}
