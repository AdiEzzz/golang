package bootcamp

import (
	"bootcamp/firststruct"

	"github.com/alem-platform/ap"
)

func PrintUserInfo(u firststruct.User) {
	printString("Name: ")
	printString(u.Name)
	ap.PutRune('\n')
	printString("HasPassword: ")
	if len(u.GetPassword()) == 0 {
		printString("no")
	} else {
		printString("yes")
	}
	ap.PutRune('\n')
}

func printString(s string) {
	for _, v := range s {
		ap.PutRune(v)
	}
}
