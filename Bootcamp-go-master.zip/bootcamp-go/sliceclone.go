package bootcamp

// import "fmt"

func SliceClone(src, dst *[]int) {
	*dst = make([]int, len(*src))
	for i, v := range *src {
		(*dst)[i] = v
	}
}

// func main() {
//     var arr = make([]int, 10)
//     for i, v := range []int{10, 20, 13, 5, 12, 31} {
//         arr[i] = v
//     }

//     var clone = []int{0, 20, 13, 5, 12, 31, 15, 23, 99, 1515, 645874, 45646}

//     fmt.Println("arr:", arr, len(arr), cap(arr))        // arr: [10, 20, 13, 5, 12, 31] 6 10
//     fmt.Println("clone:", clone, len(clone), cap(arr))  // clone: [] 0 0

//     SliceClone(&arr, &clone)

//     fmt.Println("arr:", arr, len(arr), cap(arr))        // arr: [10, 20, 13, 5, 12, 31] 6 10
//     fmt.Println("clone:", clone, len(clone), cap(arr))  // clone: [10, 20, 13, 5, 12, 31] 6 10
// }