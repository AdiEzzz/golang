package main

import "github.com/alem-platform/ap"

func print_int(n int) {
	tmp1 := n / 10
	tmp2 := n % 10
	ap.PutRune(rune(tmp1 + 48))
	ap.PutRune(rune(tmp2 + 48))
}

func main() {
	for i := 0; i < 24; i++ {
		for j := 0; j < 60; j++ {
			if i < 10 {
				ap.PutRune('0')
				ap.PutRune(rune(i + 48))
			} else {
				print_int(i)
			}

			ap.PutRune(':')

			if j < 10 {
				ap.PutRune('0')
				ap.PutRune(rune(j + 48))
			} else {
				print_int(j)
			}
			ap.PutRune('\n')
		}
	}
}
