package main

import "github.com/alem-platform/ap"

func print_reverse(s string) {
	if len(s) == 0 {
		return
	}
	print_reverse(s[1:])
	ap.PutRune([]rune(s)[0])
}

func main() {
	print_reverse("0123456789")
	ap.PutRune('\n')
}
