grep '!' poem.txt | wc -l
