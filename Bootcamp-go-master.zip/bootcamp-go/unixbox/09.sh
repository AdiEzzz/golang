shuf -n 2 poem.txt
