sort poem.txt | uniq -u
