cat poem.txt | head -7 | tail -1
