cat poem.txt | head -2 | tail -1
