#!/bin/bash
grep -m1 "W" poem.txt
