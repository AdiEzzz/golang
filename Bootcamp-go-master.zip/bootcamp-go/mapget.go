package bootcamp

// import "fmt"

func MapGet(m map[string]int, key string) int {
	res, ok := m[key]
	if !ok {
		return 0
	}
	return res
}

// func main() {
// 	m := map[string]int{"one": 1, "two": 2, "three": 3}
// 	fmt.Println(MapGet(m, "two"))  // 2
// 	fmt.Println(MapGet(m, "four")) // 0
// }
