package main

import (
	"fmt"

	"bootcamp/stack"
)

func main() {
	stack := stack.NewStack
	stack.Push(10)
	stack.Push(20)
	fmt.Println(stack.Pop()) // 20
	fmt.Println(stack.Pop()) // 10
}
