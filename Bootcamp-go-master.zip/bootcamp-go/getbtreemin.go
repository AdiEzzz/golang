package bootcamp

import (
	"bootcamp/btree"
)

func GetMin(b *btree.BTree) *btree.BTreeNode {
	if b.Root == nil {
		return nil
	}
	return GetMinValue(b.Root)
}

func GetMinValue(node *btree.BTreeNode) *btree.BTreeNode {
	if node.Left == nil {
		return node
	} else {
		return GetMinValue(node.Left)
	}
}
