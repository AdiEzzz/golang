package main

import (
	"os"

	"github.com/alem-platform/ap"
)

func main() {
	filenames := os.Args[1:]
	var last_char rune
	for _, v := range filenames {
		content, err := os.ReadFile(v)
		if err != nil {
			printString("my_cat: ")
			printString(v + ": ")
			printString("No such file or directory\n")
			continue
		}
		// fmt.Println(content)

		for j := 0; j < len(content); j++ {
			if j != 0 && content[j] == '\n' && content[j-1] == '\n' {
				continue
			}
			ap.PutRune(rune(content[j]))
			last_char = rune(content[j])
		}

		// for j, v := range content {
		// 	if v == '\n'
		// 	ap.PutRune(rune(v))
		// }
	}
	if len(filenames) == 0 {
		printString("usage: my_cat file ...\n")
	}
	if last_char != '\n' {
		ap.PutRune('\n')
	}
}

func printString(s string) {
	str := []rune(s)
	for i := 0; i < len(str); i++ {
		ap.PutRune(str[i])
	}
}
