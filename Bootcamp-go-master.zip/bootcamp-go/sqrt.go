package bootcamp

// import "fmt"

func Sqrt(x int) int {
	if x < 0 {
		return -1
	}
	res := 1
	for res <= x {
		if res*res == x {
			return res
		}
		res += 1
	}
	return 0
}

// func main() {
// 	fmt.Println(Sqrt(64)) // 4
// 	fmt.Println(Sqrt(0))  // 1
// 	fmt.Println(Sqrt(3))  // -1
// 	fmt.Println(Sqrt(1))  // 0
// }
