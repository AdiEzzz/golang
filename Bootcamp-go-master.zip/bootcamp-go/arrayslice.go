package bootcamp

// import "fmt"

func ArraySlice(arr [20]int, low int, high int) []int {
	var res []int
	if low >= high || low < 0 || high <0 || low >= len(arr) || high >= len(arr){
		return res
	}
	for i := low; i < high; i++ {
		res = append(res, arr[i])
	}
	return res
}

// func main() {
//     arr := [20]int{0, 1, 2, 3, 4, 5, 6, 7, 8, 9}
//     fmt.Println(ArraySlice(arr, -1, 5)) // [3, 4]
//     fmt.Println(ArraySlice(arr, 5, 5)) // []
//     fmt.Println(ArraySlice(arr, 5, 1)) // []
// }