package main

import (
	"fmt"

	"github.com/alem-platform/ap"
)

func PutNumber(n int) {
	if n < 0 {
		ap.PutRune('-')
		n = n - 2*n
	}
	if n == 0 {
		return
	}
	tmp := n % 10
	PutNumber(n / 10)
	ap.PutRune(rune(tmp + '0'))
}

func main() {
	var n int = 0
	var mx, mn int
	fmt.Scanf("%d", &n)
	nums := make([]int, n)

	for i := 0; i < n; i++ {
		fmt.Scan(&nums[i])
	}
	mx, mn = nums[0], nums[0]
	for _, v := range nums {
		if v > mx {
			mx = v
		}
		if v < mn {
			mn = v
		}
	}
	PutNumber(mx)
	ap.PutRune(' ')
	PutNumber(mn)
	ap.PutRune('\n')
}

// func main() {
// 	var n int = 0
// 	fmt.Scanf("%d", &n)
// 	lines := make([]rune, n)
// 	for i := 0; i < n; i++ {
// 		fmt.Scanf("%c", &lines[i])
// 	}

// 	for i := 0; i < n; i++ {

// 		PutNumber(int(lines[i]))
// 		if i < n-1 {
// 			ap.PutRune(' ')
// 		}
// 	}
// }
