package bootcamp

// import "github.com/alem-platform/ap"

func NthRune(s string, n int) rune {
	if len(s) == 0 || n < 0 || n >= len(s) {
		return 0
	}
	return rune(s[n])
}

// func main() {
// 	ap.PutRune(NthRune("salem", 0))
// 	ap.PutRune(NthRune("student", 2))
// 	ap.PutRune('\n')
// }
