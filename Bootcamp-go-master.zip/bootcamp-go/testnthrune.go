package bootcamp

func TestNthRune(fn func(s string, n int) rune) bool {
	testCases := []struct {
		s        string
		n        int
		expected rune
	}{
		{s: "abcdef", n: 3, expected: 'c'}, // Normal case
		{s: "hello", n: 1, expected: 'h'},  // First rune
		{s: "world", n: 5, expected: 'd'},  // Last rune
		{s: "", n: 1, expected: -1},        // Empty string
		{s: "abc", n: 0, expected: -1},     // n <= 0
		{s: "xyz", n: 4, expected: -1},     // n > len(s)
	}

	for _, test := range testCases {
		result := fn(test.s, test.n)
		if result != test.expected {
			return false
		}
	}

	return true
}
