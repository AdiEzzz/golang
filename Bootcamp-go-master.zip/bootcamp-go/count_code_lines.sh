#!/bin/bash

usage() {
    echo "usage: ./count_code_lines dir_path"
}

if [ $# -eq 0 ]; then
    usage
    exit 0
fi

DIR_PATH=$1

if [ ! -d "$DIR_PATH" ]; then
    if [ -e "$DIR_PATH" ]; then
        echo "error: $DIR_PATH is not a directory"
    else
        echo "error: directory $DIR_PATH not found"
    fi
    exit 0
fi

EXCLUDE_DIRS="node_modules|build|dest|.git"

CODE_LINES=$(find "$DIR_PATH" -type d \( -name node_modules -o -name build -o -name dest -o -name .git \) -prune -o -type f -print | xargs grep -v '^\s*$' | wc -l)

echo $CODE_LINES