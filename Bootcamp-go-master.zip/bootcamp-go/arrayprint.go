package bootcamp

import (
	"github.com/alem-platform/ap"
)

func num(n int) {
	if n < 0 {
		ap.PutRune('-')
		n = n - 2*n
	}
	if n == 0 {
		return
	}
	tmp := n % 10
	PutNumber(n / 10)
	ap.PutRune(rune(tmp + '0'))
}

func ArrayPrint(arr [20]int) {
	for i := 0; i < len(arr); i++ {
		num(arr[i])
		if i < len(arr)-1 {
			ap.PutRune(' ')
		}
	}
}

// func main() {
// 	arr := [20]int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20}
// 	ArrayPrint(arr)
// 	// Output:
// 	// 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20
// }
