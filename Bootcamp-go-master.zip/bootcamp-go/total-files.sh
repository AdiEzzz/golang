#!/bin/bash
find ./total/ -type f | wc -l
