package bootcamp

func ToggleBits(n byte) byte {
	return ^n
}
