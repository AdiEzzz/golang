package stack

type Stack struct {
	items []interface{}
	// Implement the internal structure as you see fit
}

func NewStack() *Stack {
	return &Stack{}
}

func (s *Stack) Push(v interface{}) {
	s.items = append(s.items, v)
}

func (s *Stack) Pop() interface{} {
	// Remove and return the item at the top of the stack
	if len(s.items) == 0 {
		return nil
	}
	pop := s.items[len(s.items)-1]
	s.items = s.items[:len(s.items)-1]
	return pop
}
