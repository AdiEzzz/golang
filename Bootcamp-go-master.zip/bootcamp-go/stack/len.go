package stack

func (s *Stack) Len() int {
	return len(s.items)
}
