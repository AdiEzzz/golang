package btree

func (b *BTree) PostOrderTraversal(fn func(n *BTreeNode)) {
	b.Root.PostOrder(fn)
}

func (b *BTreeNode) PostOrder(fn func(n *BTreeNode)) {
	if b == nil {
		return
	}
	b.Left.PostOrder(fn)
	b.Right.PostOrder(fn)
	fn(b)
}
