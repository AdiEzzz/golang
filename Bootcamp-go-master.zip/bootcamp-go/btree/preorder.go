package btree

func (b *BTree) PreOrderTraversal(fn func(n *BTreeNode)) {
	b.Root.PreOrder(fn)
}

func (b *BTreeNode) PreOrder(fn func(n *BTreeNode)) {
	if b == nil {
		return
	}
	fn(b)
	b.Left.PreOrder(fn)
	b.Right.PreOrder(fn)
}
