package btree

func (b *BTree) InOrderTraversal(fn func(n *BTreeNode)) {
	b.Root.inOrder(fn)
}

func (b *BTreeNode) inOrder(fn func(n *BTreeNode)) {
	if b == nil {
		return
	}
	b.Left.inOrder(fn)
	fn(b)
	b.Right.inOrder(fn)
}
