package btree

func (b *BTree) Clone() *BTree {
	res := NewBTree()
	if b.Root == nil {
		return res
	}
	res.ReplaceOrInsert(b.Root.Value)
	implement(res, b.Root.Left)
	implement(res, b.Root.Right)
	return res
}

func implement(copyTree *BTree, node *BTreeNode) {
	if node == nil {
		return
	}
	copyTree.ReplaceOrInsert(node.Value)
	implement(copyTree, node.Left)
	implement(copyTree, node.Right)
}
