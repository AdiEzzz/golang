package btree

type BTree struct {
	Root *BTreeNode
}

type BTreeNode struct {
	Parent      *BTreeNode
	Left, Right *BTreeNode
	Value       int
}

func NewBTree() *BTree {
	return &BTree{}
}

func (b *BTree) ReplaceOrInsert(v int) {
	if b.Root == nil {
		b.Root = &BTreeNode{Value: v}
		return
	}
	b.Root.insert(v)
}

func (node *BTreeNode) insert(v int) {
	if v < node.Value {
		if node.Left == nil {
			node.Left = &BTreeNode{Parent: node, Value: v}
		} else {
			node.Left.insert(v)
		}
	} else {
		if node.Right == nil {
			node.Right = &BTreeNode{Parent: node, Value: v}
		} else {
			node.Right.insert(v)
		}
	}
}
