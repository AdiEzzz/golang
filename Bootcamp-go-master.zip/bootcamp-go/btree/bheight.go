package btree

func (node *BTreeNode) BHeight() int {
	if node == nil {
		return 0
	}
	leftH := node.Left.BHeight()
	rightH := node.Right.BHeight()
	return maxx(leftH, rightH) + 1
}

func maxx(a, b int) int {
	if a > b {
		return a
	}
	return b
}
