package btree

func (b *BTree) DeleteNode(value int) {
	if b.Root == nil {
		return
	}
	b.Root = DelNode(b.Root, value)
}

func DelNode(root *BTreeNode, value int) *BTreeNode {
	if root == nil {
		return root
	} else if value < root.Value {
		root.Left = DelNode(root.Left, value)
	} else if value > root.Value {
		root.Right = DelNode(root.Right, value)
	} else {
		if root.Left == nil && root.Right == nil {
			root = nil
		} else if root.Left == nil { // Case 2: On of the child is nil
			return root.Right
		} else if root.Right == nil { // Case 2: On of the child is nil
			return root.Left
		} else { // Case 3: Node has 2 children
			temp := getMin(root.Right)
			root.Value = temp.Value
			root.Right = DelNode(root.Right, temp.Value)
		}
	}
	// root.Value is equal to our target
	// Case 1: No child

	return root
}

func getMin(node *BTreeNode) *BTreeNode {
	if node.Left == nil {
		return node
	} else {
		return getMin(node.Left)
	}
}
