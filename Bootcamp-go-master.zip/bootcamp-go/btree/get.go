package btree

func (b *BTree) Get(value int) *BTreeNode {
	if b.Root == nil {
		return nil
	}
	return b.Root.getNode(value)
}

func (node *BTreeNode) getNode(value int) *BTreeNode {
	if node == nil || node.Value == value {
		return node
	}
	if value < node.Value {
		return node.Left.getNode(value)
	}
	return node.Right.getNode(value)
}
