package bootcamp

// import "fmt"

func Some(arr []int, fn func(int) bool) bool {
	res := false
	for _, v := range arr {
		if fn(v) {
			res = true
		}
	}
	return res
}

// func main() {
// 	isEven := func(n int) bool {
// 		return n%2 == 0
// 	}

// 	result := Some([]int{1, 3, 5, 7, 8}, isEven)
// 	fmt.Println(result) // true

// 	result = Some([]int{1, 3, 5, 7}, isEven)
// 	fmt.Println(result) // false
// }
