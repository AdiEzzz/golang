package bootcamp

// import "fmt"

func IslandRemove(matrix [][]int, x, y int) {
	if x < 0 || y < 0 || y >= len(matrix) || x >= len((matrix)[0]) || matrix[y][x] == 0 {
		return
	}

	matrix[y][x] = 0

	IslandRemove(matrix, x-1, y)
	IslandRemove(matrix, x+1, y)
	IslandRemove(matrix, x, y-1)
	IslandRemove(matrix, x, y+1)
}

// func print(matrix [][]int) {
// 	for _, v := range matrix {
// 		fmt.Println(v)
// 	}
// 	fmt.Println()
// }

// func main() {
// 	matrix := [][]int{
// 		{1, 1, 1, 0, 0, 0, 0, 0, 0},
// 		{1, 1, 0, 0, 1, 0, 0, 0, 0},
// 		{0, 0, 0, 1, 2, 3, 1, 0, 0},
// 		{0, 0, 0, 1, 1, 1, 0, 0, 1},
// 		{0, 1, 0, 0, 0, 0, 0, 1, 2},
// 		{0, 0, 0, 1, 0, 0, 0, 0, 1},
// 		{0, 0, 1, 1, 2, 2, 0, 0, 0},
// 	}
// 	print(matrix)
// 	// Output:
// 	// 1 1 1 0 0 0 0 0 0
// 	// 1 1 0 0 1 0 0 0 0
// 	// 0 0 0 1 2 3 1 0 0
// 	// 0 0 0 1 1 1 0 0 1
// 	// 0 1 0 0 0 0 0 1 2
// 	// 0 0 0 1 0 0 0 0 1
// 	// 0 0 1 1 2 2 0 0 0

// 	IslandRemove(matrix, 2, 0)

// 	print(matrix)
// 	// Output:
// 	// 1 1 1 0 0 0 0 0 0
// 	// 1 1 0 0 0 0 0 0 0
// 	// 0 0 0 0 0 0 0 0 0
// 	// 0 0 0 0 0 0 0 0 1
// 	// 0 1 0 0 0 0 0 1 2
// 	// 0 0 0 1 0 0 0 0 1
// 	// 0 0 1 1 2 2 0 0 0
// 	// [1 1 1 0 0 0 0 0 0]
// 	// [1 1 0 0 0 0 0 0 0]
// 	// [0 0 0 0 0 0 0 0 0]
// 	// [0 0 0 0 0 0 0 0 1]
// 	// [0 1 0 0 0 0 0 1 2]
// 	// [0 0 0 1 0 0 0 0 1]
// 	// [0 0 1 1 2 2 0 0 0]
// }
