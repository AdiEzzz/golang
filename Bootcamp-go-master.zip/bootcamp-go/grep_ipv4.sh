#!/bin/bash

if [ $# -eq 0 ]; then
    echo "Usage: $0 <file>"
    exit 1
fi

file=$1

if [ ! -f "$file" ]; then
    echo "File not found!"
    exit 1
fi

grep -Eo '([0-9]{1,3}.){3}[0-9]{1,3}' "$file" | awk -F. '{
    if ($1 <= 255 && $2 <= 255 && $3 <= 255 && $4 <= 255) 
        print $0
}'