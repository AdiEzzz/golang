package bootcamp

import "bootcamp/btree"

func CountBtreeLeaves(b *btree.BTree) int {
	if b.Root == nil {
		return 0
	} else if b.Root.Left == nil && b.Root.Right == nil {
		return 1
	}
	return countLeafNodes(b.Root.Left) + countLeafNodes(b.Root.Right)
}

func countLeafNodes(b *btree.BTreeNode) int {
	if b == nil {
		return 0
	}
	if b.Left == nil && b.Right == nil {
		return 1
	}
	return countLeafNodes(b.Left) + countLeafNodes(b.Right)
}
