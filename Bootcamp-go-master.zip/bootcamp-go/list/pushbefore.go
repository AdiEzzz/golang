package list

func (l *List) PushBefore(n *ListNode, v interface{}) {
	newNode := &ListNode{n, v}
	if l.Head == n {
		l.Head = newNode
		return
	}
	current := l.Head
	for current.Next != n {
		current = current.Next
	}
	current.Next = newNode
}
