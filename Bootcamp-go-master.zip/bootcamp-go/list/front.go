package list

func (l *List) Front() *ListNode {
	return l.Head
}
