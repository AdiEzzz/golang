package list

func (l *List) ForEach(fn func(n *ListNode)) {
	if l.Head == nil && l.Tail == nil {
		return
	}
	current := l.Head
	for current != nil {
		fn(current)
		current = current.Next
	}
}
