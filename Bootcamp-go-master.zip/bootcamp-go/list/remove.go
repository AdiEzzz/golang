package list

func (l *List) Remove(n *ListNode) {
	if l.Head == n {
		l.Head = l.Head.Next
		return
	}
	current := l.Head
	for {
		if current.Next == n {
			current.Next = n.Next
			break
		}
		if current == l.Tail {
			break
		}

		current = current.Next
	}
}
