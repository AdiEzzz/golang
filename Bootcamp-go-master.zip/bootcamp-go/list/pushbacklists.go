package list

func (l *List) PushBackLists(lists ...*List) {
	for i := 0; i < len(lists); i++ {
		if lists[i].Head != nil {
			l.Tail.Next = lists[i].Head
			l.Tail = lists[i].Tail
		}
	}
}
