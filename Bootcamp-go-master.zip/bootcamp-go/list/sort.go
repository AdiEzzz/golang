package list

func (l *List) merge(left *ListNode, right *ListNode, fn func(a *ListNode, b *ListNode) int) *ListNode {
	dummy := &ListNode{}
	current := dummy

	for left != nil && right != nil {
		if fn(left, right) < 0 {
			current.Next = left
			left = left.Next
		} else {
			current.Next = right
			right = right.Next
		}
		current = current.Next
	}

	if left != nil {
		current.Next = left
	}
	if right != nil {
		current.Next = right
	}

	return dummy.Next
}

func (l *List) split(head *ListNode) (*ListNode, *ListNode) {
	if head == nil || head.Next == nil {
		return head, nil
	}

	slow, fast := head, head.Next
	for fast != nil && fast.Next != nil {
		slow = slow.Next
		fast = fast.Next.Next
	}

	next := slow.Next
	slow.Next = nil

	return head, next
}

func (l *List) MergeSort(head *ListNode, fn func(a *ListNode, b *ListNode) int) *ListNode {
	if head == nil || head.Next == nil {
		return head
	}

	left, right := l.split(head)

	left = l.MergeSort(left, fn)
	right = l.MergeSort(right, fn)

	return l.merge(left, right, fn)
}

func (l *List) Sort(fn func(a *ListNode, b *ListNode) int) {
	l.Head = l.MergeSort(l.Head, fn)
}

// func (l *List) Sort(fn func(a, b *ListNode) int) {
// 	if l.Head == nil || l.Head.Next == nil {
// 		return
// 	}

// 	sorted := l.Head
// 	unsorted := l.Head.Next
// 	sorted.Next = nil

// 	for unsorted != nil {
// 		current := unsorted
// 		unsorted = unsorted.Next

// 		if fn(current, sorted) < 0 {
// 			current.Next = sorted
// 			sorted = current
// 		} else {
// 			search := sorted
// 			for search.Next != nil && fn(current, search.Next) > 0 {
// 				search = search.Next
// 			}
// 			current.Next = search.Next
// 			search.Next = current
// 		}
// 	}

// 	l.Head = sorted
// }
