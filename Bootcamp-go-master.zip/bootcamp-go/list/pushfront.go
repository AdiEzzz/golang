package list

func (l *List) PushFront(v interface{}) {
	newNode := &ListNode{l.Head, v}
	if l.Head == nil {
		l.Head = newNode
		l.Tail = newNode
	} else {
		newNode.Next = l.Head
		l.Head = newNode
	}
}

// func main() {
// 	l := list.NewList()
// 	l.PushFront(10)
// 	l.PushFront(20)
// 	l.PushFront(30)

// 	node := l.Head
// 	for node != nil {
// 		fmt.Println(node.Value)
// 		node = node.Next
// 	}
// 	// Output:
// 	// 30
// 	// 20
// 	// 10
// }
