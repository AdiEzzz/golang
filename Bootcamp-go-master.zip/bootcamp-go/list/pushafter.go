package list

func (l *List) PushAfter(n *ListNode, v interface{}) {
	newNode := &ListNode{n.Next, v}

	n.Next = newNode

	if l.Tail == n {
		l.Tail = newNode
	}
}
