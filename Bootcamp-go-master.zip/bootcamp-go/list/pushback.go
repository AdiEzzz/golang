package list

// func (l *List) PushBack(v interface{}) {
// 	newNode := &ListNode{nil, v}

// 	if l.Head == nil {
// 		l.Head = newNode
// 	}
// 	current := l.Head
// 	for current.Next != nil {
// 		current = current.Next
// 	}
// 	current.Next = newNode
// }

func (l *List) PushBack(v interface{}) {
	newNode := &ListNode{Value: v, Next: nil}

	if l.Head == nil {
		l.Head = newNode
		l.Tail = newNode
		return
	}

	l.Tail.Next = newNode
	l.Tail = newNode
}
