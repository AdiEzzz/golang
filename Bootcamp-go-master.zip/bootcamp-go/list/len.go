package list

func (l *List) Len() int {
	if l.Head == nil && l.Tail == nil {
		return 0
	}
	count := 1
	current := l.Head
	for current != l.Tail {
		count++
		current = current.Next
	}

	return count
}
