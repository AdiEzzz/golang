package list

func (l *List) RemoveIf(fn func(n *ListNode) bool) {
	if l.Head == nil {
		return
	}
	current := l.Head
	for {
		if fn(current) {
			l.Remove(current)
		}

		// break if tail
		if current == l.Tail {
			break
		}
		// Update Current
		current = current.Next
	}
}
