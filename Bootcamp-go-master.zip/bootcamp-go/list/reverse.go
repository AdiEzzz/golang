package list

func (l *List) Reverse() {
	var prev *ListNode
	current := l.Head
	for current != nil {
		next := current.Next // To store next pointer cause we change it further
		current.Next = prev  // Changchin pointer to prev
		prev = current       // Prev beacme current
		current = next       // Current became next
	}
	l.Head = prev // head became last element
}
