package list

func (l *List) Back() *ListNode {
	return l.Tail
}
