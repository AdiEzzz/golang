package main

import "github.com/alem-platform/ap"

func main() {
	ap.PutRune('S')
	ap.PutRune('a')
	ap.PutRune('l')
	ap.PutRune('e')
	ap.PutRune('m')
	ap.PutRune('!')
}
