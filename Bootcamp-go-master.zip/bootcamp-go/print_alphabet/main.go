package main

import "github.com/alem-platform/ap"

func main() {
	for _, v := range "abcdefghijklmnopqrstuvwxyz" {
		ap.PutRune(v)
	}
	ap.PutRune('\n')
}
