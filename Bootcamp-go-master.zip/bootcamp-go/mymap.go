package bootcamp

type MyMap struct {
	MyMap []struct {
		Key   string
		Value interface{}
	}
}

func (m *MyMap) Set(k string, v interface{}) {
	pair := struct {
		Key   string
		Value interface{}
	}{k, v}

	for i, v := range m.MyMap {
		if v.Key == k {
			m.MyMap[i] = pair
		}
	}
	m.MyMap = append(m.MyMap, pair)
}

func (m *MyMap) Get(k string) interface{} {
	for _, v := range m.MyMap {
		if v.Key == k {
			return v.Value
		}
	}
	return nil
}

func (m *MyMap) Has(k string) bool {
	for _, v := range m.MyMap {
		if v.Key == k {
			return true
		}
	}
	return false
}

func (m *MyMap) Delete(k string) {
	for i, v := range m.MyMap {
		if v.Key == k {
			m.MyMap = append(m.MyMap[:i], m.MyMap[i+1:]...)
		}
	}
}

func (m *MyMap) Items() []struct {
	Key   string
	Value interface{}
} {
	return m.MyMap
}
