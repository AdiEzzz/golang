package main

import (
	"os"

	"github.com/alem-platform/ap"
)

func main() {
	args_len := len(os.Args[1:])
	if args_len == 0 {
		ap.PutRune('0')
	} else {
		number(args_len)
	}
	ap.PutRune('\n')
}

func number(n int) {
	if n == 0 {
		return
	}
	tmp := n % 10
	number(n / 10)
	ap.PutRune(rune(tmp + '0'))
}
