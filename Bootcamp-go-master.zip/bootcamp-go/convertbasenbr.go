package bootcamp

func ConvertBaseNbr(n string, base string) int {
	if len(base) < 2 {
		return -1
	}

	baseMap := make(map[byte]int)
	for i := 0; i < len(base); i++ {
		if _, exists := baseMap[base[i]]; exists { // if chars in base repeated check
			return -1
		}
		baseMap[base[i]] = i
	}

	result := 0
	baseLength := len(base)

	for i := 0; i < len(n); i++ {
		digit := n[i]
		if index, exists := baseMap[digit]; exists {
			result = result*baseLength + index
		} else {
			return -1
		}
	}

	return result
}

// func main() {
// 	fmt.Println(ConvertBaseNbr("1465", "0123456789"))      // 1465
// 	fmt.Println(ConvertBaseNbr("10110111001", "01"))       // 1465
// 	fmt.Println(ConvertBaseNbr("2671", "01234567"))        // 1465
// 	fmt.Println(ConvertBaseNbr("5B9", "0123456789ABCDEF")) // 1465
// 	fmt.Println(ConvertBaseNbr("1", "00"))                 // -1
// }
