package bootcamp

// import "fmt"

func MorseToText(s string) string {
	morsetable := map[rune]string{
		'A': ".-",
		'B': "-...",
		'C': "-.-.",
		'D': "-..",
		'E': ".",
		'F': "..-.",
		'G': "--.",
		'H': "....",
		'I': "..",
		'J': ".---",
		'K': "-.-",
		'L': ".-..",
		'M': "--",
		'N': "-.",
		'O': "---",
		'P': ".--.",
		'Q': "--.-",
		'R': ".-.",
		'S': "...",
		'T': "-",
		'U': "..-",
		'V': "...-",
		'W': ".--",
		'X': "-..-",
		'Y': "-.--",
		'Z': "--..",
		'1': ".----",
		'2': "..---",
		'3': "...--",
		'4': "....-",
		'5': ".....",
		'6': "-....",
		'7': "--...",
		'8': "---..",
		'9': "----.",
		'0': "-----",
		'.': ".-.-.-",
		',': "--..--",
		'?': "..--..",
	}
	var res string
	var length int = 0
	for i, v := range s {
		if v == '.' || v == '-' {
			length++
		}
		if v == ' ' {
			letter, _ := mapkey(morsetable, s[i-length:i])
			res += string(letter)
			length = 0
		}

	}
	if length != 0 {
		letter, _ := mapkey(morsetable, s[len(s)-length:])
		res += string(letter)
	}
	return res
}

func mapkey(m map[rune]string, value string) (key rune, ok bool) {
	for k, v := range m {
		if v == value {
			key = k
			ok = true
			return
		}
	}
	return
}

// func main() {
// 	fmt.Println(MorseToText("... --- ..."))                                                       // SOS
// 	fmt.Println(MorseToText("... .- .-.. . -- --..-- .... --- .-- .- .-. . -.-- --- ..- ..--..")) // SALEM,HOWAREYOU?
// }
