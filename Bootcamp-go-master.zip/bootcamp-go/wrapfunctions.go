package bootcamp

import "github.com/alem-platform/ap"

// import (
// 	"fmt"

// 	"github.com/alem-platform/ap"
// )

func WrapperPrintStr(fn func(str *string)) func(str *string) {
	ans := func(str *string) {
		for _, v := range *str {
			ap.PutRune(rune(v))
		}
		ap.PutRune('\n')
	}
	return ans
}

func WrapperRot1(fn func(str *string)) func(str *string) {
	ans := func(str *string) {
		gg := ""
		for _, char := range *str {
			if char >= 'A' && char <= 'Z' {
				gg += string((char-'A'+rune(1))%26 + 'A')
			} else if char >= 'a' && char <= 'z' {
				gg += string((char-'a'+rune(1))%26 + 'a')
			} else {
				gg += string(char)
			}
		}
		*str = gg
	}
	return ans
}

func WrapperRot13(fn func(str *string)) func(str *string) {
	ans := func(str *string) {
		arr := []rune(*str)
		for i := 0; i < len(arr); i++ {
			if 77 < arr[i] && arr[i] < 91 {
				arr[i] = (13 - (90 - arr[i])) + 64
			} else if 64 < arr[i] && arr[i] < 78 {
				arr[i] = rune(arr[i] + 13)
			} else if 109 < arr[i] && arr[i] < 123 {
				arr[i] = (13 - (122 - arr[i])) + 96
			} else if 96 < arr[i] && arr[i] < 110 {
				arr[i] = rune(arr[i] + 13)
			}
		}
		*str = string(arr)
	}
	return ans
}

func WrapperReverseStr(fn func(str *string)) func(str *string) {
	ans := func(str *string) {
		runes := []rune(*str)
		for i, j := 0, len(runes)-1; i < j; i, j = i+1, j-1 {
			runes[i], runes[j] = runes[j], runes[i]
		}
		*str = string(runes)
	}
	return ans
}

func WrapFunctions(decs []func(fn func(str *string)) func(str *string)) func(str *string) {
	ans := func(str *string) {
		for i := range decs {
			smth := decs[i](func(s *string) {
				return
			})
			smth(str)
		}
	}
	return ans
}

// func main() {
// 	mockFn := func(str *string) {
// 		return
// 	}

// 	fnPrint := WrapperPrintStr(mockFn)

// 	str := "salem?"
// 	fnPrint(&str) // salem?

// 	fnRot1 := WrapperRot1(mockFn)
// 	fnRot1(&str)
// 	fnPrint(&str) // tbmfn?

// 	fnRot13 := WrapperRot13(mockFn)
// 	fnRot13(&str)
// 	fnPrint(&str) // gozsa?

// 	fnReverse := WrapperReverseStr(mockFn)
// 	fnReverse(&str)
// 	fnPrint(&str) // ?aszog

// 	fmt.Println("United Func Results")
// 	wrappedFns := WrapFunctions([]func(fn func(str *string)) func(str *string){
// 		WrapperPrintStr,
// 		WrapperRot1,
// 		WrapperRot1,
// 		WrapperRot1,
// 		WrapperRot1,
// 		WrapperRot1,
// 		WrapperRot1,
// 		WrapperRot1,
// 		WrapperRot1,
// 		WrapperRot1,
// 		WrapperRot1,
// 		WrapperRot1,
// 		WrapperRot1,
// 		WrapperPrintStr,
// 		WrapperReverseStr,
// 		WrapperPrintStr,
// 	})
// 	wrappedFns(&str)
// 	// ?aszog
// 	// gozsa?
// 	// salem?
// }
