package bootcamp
// import "fmt"

func SliceCopy(dst, src []int) {
	var n int
	if len(src) >= len(dst){
		n = len(dst)
	}else{
		n = len(src)
	}
	for i := 0; i < n; i++ {
		dst[i] = src[i]
	}
}


// func main() {
//     var src = []int{10, 20, 13, 5, 12, 31}
//     var dst = make([]int, 4)

//     SliceCopy(dst, src)

//     fmt.Println(src, dst) // [10, 20, 13, 5, 12, 31] [10, 20, 13, 5]

//     src[0] = 0

//     fmt.Println(src, dst) // [0, 20, 13, 5, 12, 31] [10, 20, 13, 5]
// }