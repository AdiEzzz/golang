package bootcamp

// import "fmt"

func Repeat(s string, count int) string {
	var res string
	for i := 0; i < count; i++ {
		res += s
	}
	return res
}

// func main() {
// 	fmt.Println(Repeat("abc", 99)) // "abcabcabc"
// 	fmt.Println(Repeat("123", 2))  // "123123"
// }
