package bootcamp

import "bootcamp/btree"

func CountBtreeNodes(b *btree.BTree) int {
	if b.Root == nil {
		return 0
	}
	return countNodes(b.Root.Left) + countNodes(b.Root.Right) + 1
}

func countNodes(b *btree.BTreeNode) int {
	if b.Left == nil && b.Right == nil {
		return 1
	}
	if b.Left != nil && b.Right != nil {
		return countNodes(b.Left) + countNodes(b.Right) + 1
	}

	if b.Left == nil {
		return 1 + countNodes(b.Right)
	} else {
		return 1 + countNodes(b.Left)
	}
}
