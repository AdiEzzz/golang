package bootcamp

type Lock struct {
	Locked bool
}

func (l *Lock) Lock() bool {
	if !l.Locked {
		l.Locked = true
		return true
	}
	return false
}

func (l *Lock) Unlock() bool {
	if l.Locked {
		l.Locked = false
		return true
	}
	return false
}

func (l *Lock) IsLocked() bool {
	return l.Locked
}

func NewLock() Lock {
	return Lock{false}
}
