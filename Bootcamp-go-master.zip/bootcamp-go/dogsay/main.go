package main

import (
	"os"

	"github.com/alem-platform/ap"
)

func main() {
	args := os.Args[1:]
	length := len(args)
	var text, dogtype string

	if length == 1 && args[0] != "-b" {
		text = args[0]
		dogtype = "simple"
	} else if length == 3 && args[0] == "-b" {
		text = args[2]
		dogtype = args[1]
	} else if length == 2 {
		dogtype = args[1]
	} else {
		printString("usage: dogsay [-b cur|maltipoo|simple|tazy] text\n")
		return
	}
	DogSay(text, dogtype)
	ap.PutRune('\n')
}

// text
func printext(s string) {
	n, nws := max_line_nw(s)
	// print first
	if n+2 < 6 {
		n = 4
	}
	for i := 0; i < n+2; i++ {
		if i == 0 {
			ap.PutRune(' ')
		}
		ap.PutRune('_')
	}
	ap.PutRune('\n')
	// print center
	arr := array_by_newline(s)
	// fmt.Println(arr)

	if nws+1 == 1 {
		printString("< ")
		printString(s)
		printString(" >")
	} else {

		printString("/ ")
		printString(arr[0])
		for i := 0; i < n-len(arr[0]); i++ {
			ap.PutRune(' ')
		}
		printString(" \\")
		ap.PutRune('\n')
		// center
		for _, v := range arr[1 : len(arr)-1] {
			printString("| ")
			printString(v)
			for i := 0; i < n-len(v); i++ {
				ap.PutRune(' ')
			}
			printString(" |")
			ap.PutRune('\n')
		}
		// down
		printString("\\ ")
		printString(arr[len(arr)-1])
		for i := 0; i < n-len(arr[len(arr)-1]); i++ {
			ap.PutRune(' ')
		}
		printString(" /")
	}

	// Print last
	ap.PutRune('\n')
	for i := 0; i < n+2; i++ {
		if i == 0 {
			ap.PutRune(' ')
		}
		ap.PutRune('-')
	}
	ap.PutRune('\n')
}

func DogSay(text, dogtype string) {
	switch dogtype {
	case "simple":
		printext(text)
		printString("  \\\n" +
			"^..^      /\n" +
			"/_/\\_____/\n" +
			"   /\\   /\\\n" +
			"  /  \\ /  \\")
	case "maltipoo":
		printext(text)
		printString(
			"  \\\n" +
				"   \\ __    __\n" +
				"   o-''))_____\\\\\n" +
				"   \"--__/ * * * )\n" +
				"   c_c__/-c____/")
	case "tazy":
		printext(text)
		printString(
			"  \\                __\n" +
				"   \\___________   /  \\\n" +
				"               \\ / ..|\\\n" +
				"                (_\\  |_)\n" +
				"                /  \\@'\n" +
				"               /     \\\n" +
				"           _  /  `   |\n" +
				"          \\\\ /  \\  | _\\\n" +
				"           \\   /_ || \\\\_\n" +
				"            \\____)|_) \\_)")
	case "cur":
		printext(text)
		printString(
			"   \\\n" +
				"    \\ D\\___/\\\n" +
				"     \\ (0_o)\n" +
				"        (V)\n" +
				"----oOo--U--oOo------\n" +
				"_______|_______|_____")
	default:
		printString("usage: dogsay [-b cur|maltipoo|simple|tazy] text")
		return
	}
}

func max_line_nw(s string) (int, int) {
	res := 0
	count := 0
	nws := 0
	for i, v := range s {
		if v == '\n' {
			nws++
			if count > res {
				res = count
			}
			count = 0
		} else {
			count++
		}

		if i == len(s)-1 && v != '\n' && count > res {
			res = count
		}
	}

	return res, nws
}

func printString(s string) {
	str := []rune(s)
	for i := 0; i < len(str); i++ {
		ap.PutRune(str[i])
	}
}

func array_by_newline(s string) []string {
	if s == "" {
		return []string{}
	}
	var res []string
	tmp := ""
	for _, v := range s {
		if v == '\n' {
			res = append(res, tmp)
			tmp = ""
		} else {
			tmp += string(v)
		}
	}
	if tmp != "" || s[len(s)-1] == '\n' {
		res = append(res, tmp)
	}
	return res
}
