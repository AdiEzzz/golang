package bootcamp

func SliceUnion(slices ...[]int) []int {
	var res []int
	var add bool
	for _, slice := range slices {
		for _, v := range slice {
			add = true

			for _, val_res := range res {
				if val_res == v {
					add = false
					break
				}
			}

			if add {
				res = append(res, v)
			}
		}
	}
	return res
}

// func main() {
// 	result := SliceUnion([]int{7, 8, 3, 8, 0, 2, 0, 1, 6, 5, 0, 9}, []int{8, 2, 8, 6, 0, 4, 9, 7, 3, 6, 8, 2})
// 	fmt.Println(result) // [1, 2, 3, 20, 4, 5, 15, 0]
// }
