package bootcamp

// import (
// 	"fmt"
// )

func Join(elements []string, sep string) string {
	var res string
	for i, v := range elements {
		res += v
		if i < len(elements)-1 {
			res += sep
		}
	}
	return res
}

// func main() {
// 	fmt.Println(Join([]string{"salem", "student"}, " "))
// 	fmt.Println(Join([]string{"", "4656"}, "qwe"))
// }
