package bootcamp

// import "fmt"

func IsPrim(n int) bool {
	if n <= 1 {
		return false
	}
	for i := 2; i < n/2+1; i++ {
		if n%i == 0 {
			return false
		}
	}
	return true
}

func NextPrime(n int) int {
	if n <= 1 {
		return 2
	}
	num := n + 1
	for IsPrim(num) == false {
		num++
	}
	return num
}

// func main() {
// 	fmt.Println(NextPrime(0))   // 11
// 	fmt.Println(NextPrime(116)) // 13
// 	fmt.Println(NextPrime(-1))  // 2
// }
