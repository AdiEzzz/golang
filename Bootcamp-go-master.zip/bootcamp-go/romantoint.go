package bootcamp

// import "fmt"

func RomanToInt(s string) int {
	roman := map[string]int{
		"I": 1,
		"V": 5,
		"X": 10,
		"L": 50,
		"C": 100,
		"D": 500,
		"M": 1000,
	}
	res := 0

	for i, v := range s {
		res += roman[string(v)]
		if i != 0 {
			if roman[string(s[i-1])] < roman[string(v)] {
				res -= 2 * roman[string(s[i-1])]
			}
		}
	}
	return res
}

// func main() {
// 	fmt.Println(RomanToInt("III"))     // 3
// 	fmt.Println(RomanToInt("IV"))      // 4
// 	fmt.Println(RomanToInt("IX"))      // 9
// 	fmt.Println(RomanToInt("LVIII"))   // 58
// 	fmt.Println(RomanToInt("MCMXCIV")) // 1994
// 	fmt.Println(RomanToInt(""))        // 0
// 	fmt.Println(RomanToInt("salem"))   // 0
// }
