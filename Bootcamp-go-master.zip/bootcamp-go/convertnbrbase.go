package bootcamp

// import "fmt"

func ConvertNbrBase(n int, base string) string {
	if len(base) < 2 || n <= 0 {
		return ""
	}

	for i := 0; i < len(base); i++ {
		for j := i + 1; j < len(base); j++ {
			if base[i] == base[j] {
				return ""
			}
		}
	}

	var res string = ""
	var lenBase int = len(base)

	for n > 0 {
		res = string(base[n%lenBase]) + res
		n = n / lenBase
	}

	if res == "" {
		res = string(base[0])
	}
	return res
}

// func main() {
// 	result := ConvertNbrBase(1465, "0123456789")
// 	fmt.Println(result) // 1465

// 	result = ConvertNbrBase(1465, "01")
// 	fmt.Println(result) // 10110111001

// 	result = ConvertNbrBase(1465, "01234567")
// 	fmt.Println(result) // 2671

// 	result = ConvertNbrBase(1465, "0123456789ABCDEF")
// 	fmt.Println(result) // 5B9

// 	result = ConvertNbrBase(1465, "00")
// 	fmt.Println(result) //
// }
