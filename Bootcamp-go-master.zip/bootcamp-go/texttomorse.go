package bootcamp

// import "fmt"

func TextToMorse(s string) string {
	morsetable := map[rune]string{
		'A': ".-",
		'B': "-...",
		'C': "-.-.",
		'D': "-..",
		'E': ".",
		'F': "..-.",
		'G': "--.",
		'H': "....",
		'I': "..",
		'J': ".---",
		'K': "-.-",
		'L': ".-..",
		'M': "--",
		'N': "-.",
		'O': "---",
		'P': ".--.",
		'Q': "--.-",
		'R': ".-.",
		'S': "...",
		'T': "-",
		'U': "..-",
		'V': "...-",
		'W': ".--",
		'X': "-..-",
		'Y': "-.--",
		'Z': "--..",
		'1': ".----",
		'2': "..---",
		'3': "...--",
		'4': "....-",
		'5': ".....",
		'6': "-....",
		'7': "--...",
		'8': "---..",
		'9': "----.",
		'0': "-----",
		'.': ".-.-.-",
		',': "--..--",
		'?': "..--..",
	}
	var res string
	for i, v := range s {
		if v == ' ' {
			continue
		}
		res += morsetable[upper(v)]
		if i < len(s)-1 {
			res += " "
		}
	}
	return res
}

func upper(s rune) rune {
	if s >= 'a' && s <= 'z' {
		return rune(s - 32)
	} else {
		return s
	}
}

// func main() {
// 	fmt.Println(TextToMorse("SOS"))                 // ... --- ...
// 	fmt.Println(TextToMorse("salem, how are you?")) // ... .- .-.. . -- --..-- .... --- .-- .- .-. . -.-- --- ..- ..--..
// }
