package firststruct

func (user User) PasswordReliability() string {
	if len(user.password) == 0 {
		return "undefined"
	}

	var isLength, isUpper, isLower, isDigit, isSpecChar bool

	isLength = len(user.password) >= 8

	count := 0
	if isLength {
		count++
	}

	for _, v := range user.password {
		if v >= 'A' && v <= 'Z' && !isUpper {
			isUpper = true
			count++
		}
		if v >= 'a' && v <= 'z' && !isLower {
			isLower = true
			count++
		}
		if v >= '0' && v <= '9' && !isDigit {
			isDigit = true
			count++
		}
		if (v < '0' || v > '9' && v < 'A' || v > 'Z' && v < 'a' || v > 'z') && !isSpecChar {
			isSpecChar = true
			count++
		}
	}
	if count >= 5 {
		return "strong"
	} else if count >= 3 {
		return "medium"
	} else if count >= 1 {
		return "easy"
	} else {
		return "undefined"
	}
}
