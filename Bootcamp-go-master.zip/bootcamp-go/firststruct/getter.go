package firststruct

func (u User) GetPassword() string {
	return u.password
}
