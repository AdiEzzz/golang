package firststruct

func (u User) Compare(v User) bool {
	return u == v
}
