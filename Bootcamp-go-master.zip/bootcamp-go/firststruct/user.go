package firststruct

// import "fmt"

type User struct {
	Name, password string
}

func NewUser(name, password string) User {
	user := User{
		name,
		password,
	}
	return user
}

// func main() {
// 	u := User{
// 		Name:     "John Doe",
// 		password: "securePassword123",
// 	}
// 	fmt.Println("User:", u) // User: {John Doe securePassword123}

// 	nUser := NewUser("Alem", "Salem")
// 	fmt.Println("User:", nUser) // User: {Alem Salem}
// }
