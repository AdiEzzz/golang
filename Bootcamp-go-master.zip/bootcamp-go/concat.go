package bootcamp

// import "fmt"

func Concat(s ...string) string {
	var res string
	for _, v := range s {
		res += v
	}
	return res
}

// func main() {
// 	fmt.Println(Concat("Salem", " ", "Student!"))
// 	fmt.Println(Concat("1", "2", "3", "4", "5"))
// 	fmt.Println(Concat())
// }
