package bootcamp

// import "fmt"

func IsPalindromeWord(s string) bool {
	if len(s) == 0 {
		return false
	}
	var res string
	var res1 string
	for _, v := range s {
		if v < 'A' || (v > 'Z' && v < 'a') || v > 'z' {
			return false
		}

		if v >= 'A' && v <= 'Z' {
			res += string(rune(v + 32))
		} else {
			res += string(v)
		}
	}
	n := len(res)
	for i := 0; i < n; i++ {
		res1 += string(res[n-i-1])
	}
	return res == res1
}

// func main() {
// 	fmt.Println(IsPalindromeWord("racecar")) // true
// 	fmt.Println(IsPalindromeWord("level"))   // true
// 	fmt.Println(IsPalindromeWord("1"))       // false
// }
