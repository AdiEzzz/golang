package bootcamp

// import "fmt"

func MapClone(m map[string]int) map[string]int {
	res := map[string]int{}
	for i, v := range m {
		res[i] = v
	}
	return res
}

// func main() {
// 	m := map[string]int{"one": 1, "two": 2, "three": 3}
// 	clone := MapClone(m)
// 	fmt.Println(clone) // map[one:1 two:2 three:3]
// 	clone["four"] = 4
// 	fmt.Println(clone) // map[one:1 two:2 three:3 four:4]
// 	fmt.Println(m)     // map[one:1 two:2 three:3]
// }
