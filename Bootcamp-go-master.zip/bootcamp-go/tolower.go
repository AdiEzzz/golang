package bootcamp

// import "fmt"

func ToLower(s string) string {
	var res string
	for _, v := range s {
		if v >= 'A' && v <= 'Z' {
			res += string(rune(v + 32))
		} else {
			res += string(v)
		}
	}
	return res
}

// func main() {
// 	fmt.Println(ToLower("SALEM "))        // "salem "
// 	fmt.Println(ToLower("Salem Student")) // "salem student"
// 	fmt.Println(ToLower("S4LEm"))         // "s4lem"
// }
