package main

import (
	"os"

	"github.com/alem-platform/ap"
)

func numb(n int) {
	if n == 0 {
		ap.PutRune('0')
	} else if n == 1 {
		ap.PutRune('1')
	} else if n == 2 {
		ap.PutRune('2')
	} else if n == 3 {
		ap.PutRune('3')
	} else if n == 4 {
		ap.PutRune('4')
	} else if n == 5 {
		ap.PutRune('5')
	} else if n == 6 {
		ap.PutRune('6')
	} else if n == 7 {
		ap.PutRune('7')
	} else if n == 8 {
		ap.PutRune('8')
	} else if n == 9 {
		ap.PutRune('9')
	}
}

func recurs(w int) {
	if w != 0 {
		recurs(w / 10)
	}
	if w != 0 {
		numb(w % 10)
	}
}

func PutNumber(n int) {
	if n == 0 {
		ap.PutRune('0')
	} else {
		if n < 0 {
			ap.PutRune('-')
			n = -n
		}
		recurs(n)
	}
}

func Atoi(s string) int {
	var res int
	ln := len(s)
	isNeg := false
	// isPos := false
	n := 0
	if ln == 0 || (s[0] != '-' && s[0] != '+' && (s[0] < '0' || s[0] > '9')) {
		return 0
	}
	for i := 1; i < ln; i++ {
		if s[i] < '0' || s[i] > '9' {
			return 0
		}
	}
	if s[0] == '-' {
		isNeg = true
		n = 1
	} else if s[0] == '+' {
		// isPos = true
		n = 1
	}
	for i := n; i < ln; i++ {
		res = res*10 + int(s[i]-'0')
	}
	if isNeg {
		res = -res
	}
	return res
}

func main() {
	num := Atoi(os.Args[1])
	if num > 2147483647 || num < 0 {
		ap.PutRune('N')
		ap.PutRune('V')
		ap.PutRune('\n')
		return
	}
	var days, hours, mins, secs int
	days = num / 86400
	num = num - days*86400
	hours = num / 3600
	num = num - hours*3600
	mins = num / 60
	num = num - mins*60
	secs = num
	if days != 0 {
		PutNumber(days)
		ap.PutRune('d')
		ap.PutRune(' ')
	}
	if hours != 0 {
		if days != 0 {
		}
		PutNumber(hours)
		ap.PutRune('h')
		ap.PutRune(' ')
	}
	if mins != 0 {
		if hours != 0 {
		}
		PutNumber(mins)
		ap.PutRune('m')
		ap.PutRune(' ')
	}
	if secs != 0 {
		if mins != 0 {
		}
		PutNumber(secs)
		ap.PutRune('s')
		// ap.PutRune(' ')
	}
	ap.PutRune('\n')
}
