package bootcamp

// import (
// 	"github.com/alem-platform/ap"
// )

// Output:
// g d a
// h e b
// i f c
func SliceMatrixRotateClockwise(matrix [][]rune) {
	if len(matrix) != len(matrix[0]) {
		return
	}

	for i, j := 0, len(matrix)-1; i < j; i, j = i+1, j-1 {
		matrix[i], matrix[j] = matrix[j], matrix[i]
	}

	for i := 0; i < len(matrix); i++ {
		for j := 0; j < i; j++ {
			matrix[i][j], matrix[j][i] = matrix[j][i], matrix[i][j]
		}
	}
}

// func main() {
// 	// matrix := [][]rune{
// 	// 	{'a', 'b', 'c'},
// 	// 	{'d', 'e', 'f'},
// 	// 	{'g', 'h', 'i'},
// 	// }
// 	matrix := [][]rune{
// 		{48, 109, 94, 50, 74, 99, 106, 50},
// 		{120, 45, 77, 107, 69, 123, 89, 94},
// 		{66, 67, 60, 109, 88, 62, 94, 90},
// 		{80, 84, 64, 111, 105, 56, 40, 102},
// 		{76, 64, 123, 75, 72, 98, 100, 113},
// 		{69, 109, 102, 98, 87, 90, 121, 67},
// 		{93, 60, 79, 117, 88, 95, 90, 41},
// 	}

// 	SliceMatrixPrint(matrix)
// 	// Output:
// 	// a b c
// 	// d e f
// 	// g h i
// 	ap.PutRune('\n')
// 	SliceMatrixRotateClockwise(matrix)
// 	ap.PutRune('\n')

// 	SliceMatrixPrint(matrix)
// 	// Output:
// 	// g d a
// 	// h e b
// 	// i f c
// }

// func SliceMatrixPrint(matrix [][]rune) {
// 	for w, i := range matrix {
// 		for n, v := range i {
// 			ap.PutRune(v)
// 			if n < len(matrix[0])-1 {
// 				ap.PutRune(' ')
// 			}
// 		}
// 		if w < len(matrix)-1 {
// 			ap.PutRune('\n')
// 		}
// 	}
// }
