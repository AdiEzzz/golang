package bootcamp

import (
	"bootcamp/btree"
)

func DeleteBtreeLeaves(b *btree.BTree) {
	if b == nil {
		return
	}
	if b.Root.Left == nil && b.Root.Right == nil {
		b.Root = nil
	}
	clearLeafNodes(b.Root)
}

func clearLeafNodes(node *btree.BTreeNode) {
	if node == nil {
		return
	}
	if isLeaf(node.Left) {
		node.Left = nil
	}
	if isLeaf(node.Right) {
		node.Right = nil
	}
	clearLeafNodes(node.Left)
	clearLeafNodes(node.Right)
}

func isLeaf(node *btree.BTreeNode) bool {
	if node == nil {
		return false
	}
	if node.Left == nil && node.Right == nil {
		return true
	}
	return false
}
