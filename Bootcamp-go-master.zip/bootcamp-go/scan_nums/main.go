package main

import (
	"fmt"

	"github.com/alem-platform/ap"
)

func PutNumber(n int) {
	if n < 0 {
		ap.PutRune('-')
		n = n - 2*n
	}
	if n == 0 {
		return
	}
	tmp := n % 10
	PutNumber(n / 10)
	ap.PutRune(rune(tmp + '0'))
}

func main() {
	var a, b int
	fmt.Scanf("%d %d", &a, &b)
	PutNumber(a + b)
	ap.PutRune(' ')
	PutNumber(a - b)
	ap.PutRune(' ')
	if a == 0 || b == 0 {
		ap.PutRune('0')
	} else {
		PutNumber(a * b)
	}

	ap.PutRune(' ')
	if a/b == 0 {
		ap.PutRune('0')
	} else if b != 0 {
		PutNumber(a / b)
	} else {
		ap.PutRune('F')
	}
}
