package bootcamp

// import "fmt"

func Contains(str string, substr string) bool {
	for i := 0; i < len(str); i++ {
		if i+len(substr) <= len(str) && str[i:i+len(substr)] == substr {
			return true
		}
	}
	return false
}

// func main() {
// 	fmt.Println(Contains("hello world", ""))
// 	fmt.Println(Contains("test", "te"))
// }
