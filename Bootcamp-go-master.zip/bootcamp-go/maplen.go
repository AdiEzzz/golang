package bootcamp

// import "fmt"

func MapLen(m map[string]int) int {
	return len(m)
}

// func main() {
// 	m := map[string]int{"one": 1, "two": 2, "three": 3, "fo": 4}
// 	length := MapLen(m)
// 	fmt.Println(length) // 3
// }
