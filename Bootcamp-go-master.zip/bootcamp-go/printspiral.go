package bootcamp

import (
	"github.com/alem-platform/ap"
)

func PrintSpiral(n int) {
	if n <= 0 {
		return
	}

	matrix := make([][]int, n)
	for i := range matrix {
		matrix[i] = make([]int, n)
	}

	num := 0
	x, y := n/2, n/2
	if n%2 == 0 {
		x--
		y--
	}

	matrix[x][y] = num
	num++

	directions := [][]int{
		{0, 1},  // вправо
		{1, 0},  // вниз
		{0, -1}, // влево
		{-1, 0}, // вверх
	}
	dirIndex := 0

	step := 1
	for step < n {
		for i := 0; i < 2; i++ {
			for j := 0; j < step; j++ {
				x += directions[dirIndex][0]
				y += directions[dirIndex][1]

				if x >= 0 && x < n && y >= 0 && y < n {
					matrix[x][y] = num
					num++
				}
			}
			dirIndex = (dirIndex + 1) % 4
		}
		step++
	}

	for i := 0; i < n-1; i++ {
		x += directions[dirIndex][0]
		y += directions[dirIndex][1]
		if x >= 0 && x < n && y >= 0 && y < n {
			matrix[x][y] = num
			num++
		}
	}

	maxNum := n*n - 1
	maxDigits := digets(maxNum)

	for i := 0; i < n; i++ {
		for j := 0; j < n; j++ {
			printAligned(matrix[i][j], maxDigits)
			if j != n-1 {
				ap.PutRune(' ')
			}
		}
		if i < n-1 {
			ap.PutRune('\n')
		}

	}
}

func printAligned(num int, width int) {
	numDigits := digets(num)
	for i := 0; i < width-numDigits; i++ {
		ap.PutRune(' ')
	}
	if num == 0 {
		ap.PutRune('0')
	} else {
		numb(num)
	}
}

func digets(n int) int {
	if n == 0 {
		return 1
	}
	count := 0
	for n != 0 {
		count++
		n = n / 10
	}
	return count
}

func numb(n int) {
	if n < 0 {
		ap.PutRune('-')
		n = n - 2*n
	}
	if n == 0 {
		return
	}
	tmp := n % 10
	numb(n / 10)
	ap.PutRune(rune(tmp + '0'))
}

// func main() {
// 	PrintSpiral(1)
// 	fmt.Println()
// 	PrintSpiral(2)
// 	fmt.Println()
// 	PrintSpiral(3)
// 	fmt.Println()
// 	PrintSpiral(4)
// 	fmt.Println()
// 	PrintSpiral(5)
// }
