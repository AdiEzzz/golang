package main

import (
	"fmt"

	"github.com/alem-platform/ap"
)

func PutNumber(n int) {
	if n < 0 {
		ap.PutRune('-')
		n = n - 2*n
	}
	if n == 0 {
		return
	}
	tmp := n % 10
	PutNumber(n / 10)
	ap.PutRune(rune(tmp + '0'))
}

func main() {
	var l int = 0

	fmt.Scanf("%d", &l)

	numbers := make([]int, l)

	for i := 0; i < l; i++ {
		fmt.Scan(&numbers[i])
	}

	for i := 0; i < l; i++ {
		PutNumber(numbers[i] * 2)
		ap.PutRune(' ')
	}
}
