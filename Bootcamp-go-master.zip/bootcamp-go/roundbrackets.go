package bootcamp

// import "fmt"

func RoundBrackets(s string) bool {
	if len(s) == 0 {
		return false
	}

	stack := make([]rune, 0)

	for _, v := range s {
		if v == '(' {
			stack = append(stack, v)
		} else if v == ')' {
			if len(stack) == 0 {
				return false
			}
			stack = stack[:len(stack)-1]
		}
	}

	return len(stack) == 0
}

// func main() {
// 	fmt.Println(RoundBrackets("()()()"))   // true
// 	fmt.Println(RoundBrackets("(salem)"))  // true
// 	fmt.Println(RoundBrackets(")(1)(f)(")) // false
// 	fmt.Println(RoundBrackets("))(()"))    // false
// 	fmt.Println(RoundBrackets(""))         // false
// }
