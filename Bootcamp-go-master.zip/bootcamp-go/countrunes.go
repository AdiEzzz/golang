package bootcamp

// import "fmt"

func CountRunes(s string) int {
	count := 0
	for _, v := range s {
		if v != -1 {
			count++
		}
	}
	return count
}

// func main() {
// 	fmt.Println(CountRunes("Alem🌏"))
// }
