package main

import (
	"fmt"

	"github.com/alem-platform/ap"
)

func PutNumber(n int) {
	if n < 0 {
		ap.PutRune('-')
		n = n - 2*n
	}
	if n == 0 {
		return
	}
	tmp := n % 10
	PutNumber(n / 10)
	ap.PutRune(rune(tmp + '0'))
}

func main() {
	var n int = 0
	fmt.Scanf("%d", &n)
	lines := make([]rune, n)
	for i := 0; i < n; i++ {
		fmt.Scanf("%c", &lines[i])
	}

	for i := 0; i < n; i++ {
		ap.PutRune(lines[i])
	}
}

// func main() {
// 	var n int = 0
// 	fmt.Scanf("%d", &n)
// 	lines := make([]rune, n)
// 	for i := 0; i < n; i++ {
// 		fmt.Scanf("%c", &lines[i])
// 	}

// 	for i := 0; i < n; i++ {

// 		PutNumber(int(lines[i]))
// 		if i < n-1 {
// 			ap.PutRune(' ')
// 		}
// 	}
// }
