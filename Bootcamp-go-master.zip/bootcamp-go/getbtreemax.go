package bootcamp

import (
	"bootcamp/btree"
)

func GetMax(b *btree.BTree) *btree.BTreeNode {
	if b.Root == nil {
		return nil
	}
	return getMaxValue(b.Root)
}

func getMaxValue(node *btree.BTreeNode) *btree.BTreeNode {
	if node.Right == nil {
		return node
	} else {
		return getMaxValue(node.Right)
	}
}
