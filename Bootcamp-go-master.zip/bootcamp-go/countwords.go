package bootcamp

// import "fmt"

func lower(s string) string {
	var res string
	for _, v := range s {
		if v >= 'A' && v <= 'Z' {
			res += string(rune(v + 32))
		} else {
			res += string(v)
		}
	}
	return res
}

func CountWords(s string) map[string]int {
	res := lower(s)
	result := map[string]int{}
	onWord := false
	length := 0
	// idx := 0
	for i, v := range res {
		if v >= 'a' && v <= 'z' {
			onWord = true
			length++
		} else {
			if onWord {
				_, contains := result[res[i-length:i]]
				if !contains /*&& lower(s[i-length:i]) != res[i-length:i]*/ {
					result[res[i-length:i]] = 1
				} else {
					result[res[i-length:i]]++
				}

			}
			length = 0
			onWord = false
		}
	}
	if onWord {
		_, contains := result[res[len(s)-length:]]
		if !contains {
			result[res[len(s)-length:]] = 1
		} else {
			result[res[len(s)-length:]]++
		}
	}
	return result
}

// func main() {
// 	s := "The soup was stirred and stirred until thickened."
// 	s1 := "The soup was the stirred and stirred until thickened."
// 	wordCounts := CountWords(s)
// 	fmt.Println(wordCounts) // map[the:1 soup:1 was:1 and:1 stirred:2 until:1 thickened:1]
// 	fmt.Println(CountWords(s1))
// }
