package bootcamp

import "github.com/alem-platform/ap"

func SliceMatrixPrint(matrix [][]rune) {
	for w, i := range matrix {
		for n, v := range i {
			ap.PutRune(v)
			if n < len(matrix[0])-1 {
				ap.PutRune(' ')
			}
		}
		if w < len(matrix)-1 {
			ap.PutRune('\n')
		}
	}
}

// func main() {
// 	matrix := [][]rune{
// 		{'a', 'b', 'c'},
// 		{'d', 'e', 'f'},
// 		{'g', 'h', 'i'},
// 	}
// 	SliceMatrixPrint(matrix)
// 	// Output:
// 	// a b c
// 	// d e f
// 	// g h i
// }
